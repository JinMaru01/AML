from .model_management import Mlapp as mmt

__all__ = ["mmt"]

__version__ = "0.1.0"