# feature_engineering.py
"""
FULL UPGRADED: Feature Engineering + Data Preprocessing (Tabular, XGBoost-friendly)
Single file, single class, all @staticmethods.
Pipeline-based (replaces PreprocessorConfig).

Includes:
Preprocessing:
- Schema fit/validate
- Column inference (numeric/categorical)
- Missing values imputation + missing indicators
- Rare category grouping
- Outlier clipping (quantile/IQR)
- Scaling (standard/minmax/robust)

Encoding:
- OneHot
- Ordinal
- Frequency/Count
- Target Encoding (OOF for training + mapping for inference, supports kfold/groupkfold/timeseries)

Feature Engineering:
- Log1p features
- Power transform (Yeo-Johnson / Box-Cox)
- Binning / discretization (KBins)
- Polynomial & interaction features
- Time calendar features
- Lags + rolling stats (time series as tabular)
- Domain features: ratio, difference

Feature selection:
- Multicollinearity handling (correlation filter on final numeric features)

Utilities:
- basic_data_report
- permutation_importance_df
- compute_vif (optional statsmodels)

Artifacts are serializable with joblib.

Notes:
- For XGBoost, scaling often not needed; leave it out unless you have a reason.
- For target encoding: use is_train=True + y to generate OOF encoded training features (leakage-safe).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import KFold, TimeSeriesSplit, GroupKFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler, OrdinalEncoder, PolynomialFeatures, KBinsDiscretizer, PowerTransformer
from sklearn.inspection import permutation_importance

# Optional: VIF
try:
    import statsmodels.api as sm  # type: ignore
    from statsmodels.stats.outliers_influence import variance_inflation_factor  # type: ignore
    _HAS_STATSMODELS = True
except Exception:
    _HAS_STATSMODELS = False


# -----------------------------
# Artifacts
# -----------------------------

@dataclass
class SchemaArtifacts:
    expected_cols: List[str]
    dtypes: Dict[str, str]


@dataclass
class ColumnArtifacts:
    numeric_cols: List[str]
    categorical_cols: List[str]


@dataclass
class ImputerArtifacts:
    fill_values: Dict[str, Any]
    indicator_cols: List[str]
    # dropped_cols: List[str] = field(default_factory=list)


@dataclass
class RareCategoryArtifacts:
    cols: List[str]
    min_freq: int
    rare_token: str
    keep_values: Dict[str, set]


@dataclass
class OutlierArtifacts:
    cols: List[str]
    bounds: Dict[str, Tuple[float, float]]


@dataclass
class ScalerArtifacts:
    cols: List[str]
    kind: str
    scaler: Any


@dataclass
class OneHotArtifacts:
    cols: List[str]
    encoder: Any
    feature_names: List[str]


@dataclass
class OrdinalArtifacts:
    cols: List[str]
    encoder: Any


@dataclass
class FrequencyArtifacts:
    col: str
    count_map: Dict[Any, int]
    freq_map: Dict[Any, float]
    default_count: int
    default_freq: float


@dataclass
class TargetEncodingArtifacts:
    col: str
    # init/config
    smoothing: float = 10.0
    n_splits: int = 5
    cv_kind: str = "kfold"  # 'kfold'|'timeseries'|'groupkfold'
    group_col: Optional[str] = None
    time_col: Optional[str] = None
    # learned
    mapping: Dict[Any, float] = field(default_factory=dict)
    global_mean: float = 0.0


@dataclass
class LogArtifacts:
    cols: List[str]
    suffix: str
    clip_lower: float


@dataclass
class PowerTransformArtifacts:
    cols: List[str]
    transformer: Any


@dataclass
class BinningArtifacts:
    cols: List[str]
    binner: Any
    feature_names: List[str]


@dataclass
class PolynomialArtifacts:
    cols: List[str]
    poly: Any
    feature_names: List[str]
    drop_original: bool


@dataclass
class TimeCalendarArtifacts:
    ts_col: str
    prefix: str
    drop_original: bool


@dataclass
class LagArtifacts:
    group_cols: List[str]
    ts_col: str
    value_col: str
    lags: List[int]
    prefix: str


@dataclass
class RollingArtifacts:
    group_cols: List[str]
    ts_col: str
    value_col: str
    windows: List[int]
    stats: List[str]
    shift: int
    min_periods: int
    prefix: str


@dataclass
class DomainRatioArtifacts:
    numerator: str
    denominator: str
    out_col: str
    eps: float


@dataclass
class DomainDiffArtifacts:
    a: str
    b: str
    out_col: str


@dataclass
class MulticollinearityArtifacts:
    method: str  # 'corr'
    threshold: float
    selected_cols: List[str]
    dropped_cols: List[str]


@dataclass
class PipelineSpec:
    steps: List[Dict[str, Any]]


@dataclass
class PipelineArtifacts:
    pipeline: PipelineSpec
    schema: Optional[SchemaArtifacts]
    columns: ColumnArtifacts

    # preprocessing
    imputer: Optional[ImputerArtifacts]
    rare: Optional[RareCategoryArtifacts]
    outliers: Optional[OutlierArtifacts]
    scaler: Optional[ScalerArtifacts]

    # encoding
    encoding_type: Optional[str]
    encoding_cols: List[str]
    onehot: Optional[OneHotArtifacts]
    ordinal: Optional[OrdinalArtifacts]
    frequency: Optional[List[FrequencyArtifacts]]
    target: Optional[List[TargetEncodingArtifacts]]

    # feature engineering steps
    log: Optional[LogArtifacts]
    power: Optional[PowerTransformArtifacts]
    binning: Optional[BinningArtifacts]
    polynomial: Optional[PolynomialArtifacts]
    time_calendar: Optional[TimeCalendarArtifacts]
    lags: Optional[List[LagArtifacts]]
    rolling: Optional[List[RollingArtifacts]]
    ratios: Optional[List[DomainRatioArtifacts]]
    diffs: Optional[List[DomainDiffArtifacts]]

    # selection
    multicollinearity: Optional[MulticollinearityArtifacts]

    # output behavior
    drop_original_categoricals_after_encoding: bool = True


# -----------------------------
# Main class
# -----------------------------

class FeatureEngineering:
    # =========================
    # Pipeline builder
    # =========================
    class Pipeline:
        def __init__(self):
            """
            Update the hyperparameter grid for model tuning for SVM.

            Parameters
            ----------
            C : list of float, optional
                Regularization parameter values (default: [0.1, 1, 10, 100]).
            kernel : list of str, optional
                Kernel types to try. Options include 'linear', 'rbf', 'poly' (default: ['linear', 'rbf', 'poly']).
            gamma : list of str, optional
                Kernel coefficient options: 'scale' or 'auto' (default: ['scale', 'auto']).
            degree : list of int, optional
                Degree of the polynomial kernel (only used if kernel='poly', default: [2, 3, 4]).
            """
            self._steps: List[Dict[str, Any]] = []

        def schema(self, enforce: bool = True):
            self._steps.append({"type": "schema", "enforce": enforce})
            return self

        def infer_columns(self):
            self._steps.append({"type": "infer_columns"})
            return self

        def impute(self, numeric_strategy: str = "median", categorical_strategy: str = "most_frequent",
                   fill_value: str = "__MISSING__", add_missing_indicators: bool = True):
            self._steps.append({"type": "impute", "numeric_strategy": numeric_strategy, "categorical_strategy": categorical_strategy,
                                "fill_value": fill_value, "add_missing_indicators": add_missing_indicators})
            return self

        def rare_categories(self, min_freq: int = 20, rare_token: str = "__RARE__"):
            self._steps.append({"type": "rare", "min_freq": min_freq, "rare_token": rare_token})
            return self

        def outliers(self, method: str = "quantile", low_q: float = 0.01, high_q: float = 0.99,
                     iqr_k: float = 1.5, cols: Optional[List[str]] = None):
            self._steps.append({"type": "outliers", "method": method, "low_q": low_q, "high_q": high_q, "iqr_k": iqr_k, "cols": cols})
            return self

        def scale(self, kind: str = "standard", cols: Optional[List[str]] = None):
            self._steps.append({"type": "scale", "kind": kind, "cols": cols})
            return self

        # Encoding
        def encode_onehot(self, cols: Optional[List[str]] = None, handle_unknown: str = "ignore", drop_original: bool = True):
            self._steps.append({"type": "encode_onehot", "cols": cols, "handle_unknown": handle_unknown, "drop_original": drop_original})
            return self

        def encode_ordinal(self, cols: Optional[List[str]] = None, unknown_value: int = -1, drop_original: bool = True):
            self._steps.append({"type": "encode_ordinal", "cols": cols, "unknown_value": unknown_value, "drop_original": drop_original})
            return self

        def encode_frequency(self, cols: Optional[List[str]] = None, default_count: int = 0, default_freq: float = 0.0, drop_original: bool = True):
            self._steps.append({"type": "encode_frequency", "cols": cols, "default_count": default_count, "default_freq": default_freq, "drop_original": drop_original})
            return self

        def encode_target(self, cols: Optional[List[str]] = None, smoothing: float = 10.0, n_splits: int = 5,
                          cv_kind: str = "kfold", group_col: Optional[str] = None, time_col: Optional[str] = None,
                          drop_original: bool = True):
            self._steps.append({"type": "encode_target", "cols": cols, "smoothing": smoothing, "n_splits": n_splits,
                                "cv_kind": cv_kind, "group_col": group_col, "time_col": time_col, "drop_original": drop_original})
            return self

        # FE
        def add_log1p(self, cols: List[str], suffix: str = "_log1p", clip_lower: float = 0.0):
            self._steps.append({"type": "log1p", "cols": cols, "suffix": suffix, "clip_lower": clip_lower})
            return self

        def power_transform(self, cols: List[str], method: str = "yeo-johnson", standardize: bool = True):
            self._steps.append({"type": "power", "cols": cols, "method": method, "standardize": standardize})
            return self

        def binning(self, cols: List[str], n_bins: int = 5, strategy: str = "quantile", encode: str = "onehot-dense"):
            self._steps.append({"type": "binning", "cols": cols, "n_bins": n_bins, "strategy": strategy, "encode": encode})
            return self

        def polynomial(self, cols: List[str], degree: int = 2, include_bias: bool = False, interaction_only: bool = False, drop_original: bool = False):
            self._steps.append({"type": "polynomial", "cols": cols, "degree": degree, "include_bias": include_bias, "interaction_only": interaction_only,
                                "drop_original": drop_original})
            return self

        def time_calendar(self, ts_col: str, prefix: Optional[str] = None, drop_original: bool = False):
            self._steps.append({"type": "time_calendar", "ts_col": ts_col, "prefix": prefix, "drop_original": drop_original})
            return self

        def add_lags(self, group_cols: List[str], ts_col: str, value_col: str, lags: List[int] = [1, 7, 30], prefix: Optional[str] = None):
            self._steps.append({"type": "lags", "group_cols": group_cols, "ts_col": ts_col, "value_col": value_col, "lags": lags, "prefix": prefix})
            return self

        def add_rolling(self, group_cols: List[str], ts_col: str, value_col: str, windows: List[int] = [7, 30],
                        stats: List[str] = ["mean", "std"], shift: int = 1, min_periods: int = 3, prefix: Optional[str] = None):
            self._steps.append({"type": "rolling", "group_cols": group_cols, "ts_col": ts_col, "value_col": value_col,
                                "windows": windows, "stats": stats, "shift": shift, "min_periods": min_periods, "prefix": prefix})
            return self

        def add_ratio(self, numerator: str, denominator: str, out_col: str, eps: float = 1e-9):
            self._steps.append({"type": "ratio", "numerator": numerator, "denominator": denominator, "out_col": out_col, "eps": eps})
            return self

        def add_diff(self, a: str, b: str, out_col: str):
            self._steps.append({"type": "diff", "a": a, "b": b, "out_col": out_col})
            return self

        # selection
        def multicollinearity_corr(self, threshold: float = 0.90, cols: Optional[List[str]] = None):
            self._steps.append({"type": "multicollinearity_corr", "threshold": threshold, "cols": cols})
            return self

        def build(self) -> PipelineSpec:
            return PipelineSpec(steps=list(self._steps))

    # =========================
    # Helpers
    # =========================

    @staticmethod
    def _validate_cols_exist(df: pd.DataFrame, cols: Sequence[str], what: str = "columns"):
        missing = [c for c in cols if c not in df.columns]
        if missing:
            raise KeyError(f"Missing {what}: {missing}")

    @staticmethod
    def _infer_columns(df: pd.DataFrame) -> ColumnArtifacts:
        num_cols = df.select_dtypes(include="number").columns.tolist()
        cat_cols = [c for c in df.columns if c not in num_cols]
        return ColumnArtifacts(numeric_cols=num_cols, categorical_cols=cat_cols)

    @staticmethod
    def _make_onehot_encoder(handle_unknown: str = "ignore"):
        from sklearn.preprocessing import OneHotEncoder
        try:
            return OneHotEncoder(handle_unknown=handle_unknown, sparse_output=False)
        except TypeError:
            return OneHotEncoder(handle_unknown=handle_unknown, sparse=False)

    @staticmethod
    def basic_data_report(df: pd.DataFrame, sample_n: int = 3) -> pd.DataFrame:
        return pd.DataFrame({
            "dtype": df.dtypes.astype(str),
            "missing_pct": (df.isna().mean() * 100).round(2),
            "n_unique": df.nunique(dropna=False),
            "sample_values": [df[c].dropna().head(sample_n).tolist() for c in df.columns],
        }).sort_values(["missing_pct", "n_unique"], ascending=False)

    # =========================
    # Schema
    # =========================

    @staticmethod
    def fit_schema(df: pd.DataFrame) -> SchemaArtifacts:
        return SchemaArtifacts(expected_cols=list(df.columns), dtypes={c: str(df[c].dtype) for c in df.columns})

    @staticmethod
    def validate_schema(df: pd.DataFrame, schema: SchemaArtifacts, strict_extra: bool = False) -> None:
        missing = [c for c in schema.expected_cols if c not in df.columns]
        extra = [c for c in df.columns if c not in schema.expected_cols]
        if missing:
            raise KeyError(f"Schema violation: missing columns: {missing}")
        if strict_extra and extra:
            raise KeyError(f"Schema violation: unexpected extra columns: {extra}")

    # =========================
    # Missing
    # =========================

    @staticmethod
    def fit_imputer(df: pd.DataFrame, numeric_cols: Sequence[str], categorical_cols: Sequence[str],
                    numeric_strategy: str, categorical_strategy: str, fill_value: str, add_indicator: bool) -> ImputerArtifacts:
        fill_values: Dict[str, Any] = {}
        indicator_cols = [c for c in df.columns if add_indicator and df[c].isna().any()]

        for c in numeric_cols:
            s = pd.to_numeric(df[c], errors="coerce")
            if numeric_strategy == "median":
                fill_values[c] = float(s.median())
            elif numeric_strategy == "mean":
                fill_values[c] = float(s.mean())
            elif numeric_strategy == "most_frequent":
                fill_values[c] = s.mode(dropna=True).iloc[0] if s.notna().any() else 0.0
            else:
                raise ValueError(f"Unsupported numeric_strategy: {numeric_strategy}")

        for c in categorical_cols:
            s = df[c]
            if categorical_strategy == "most_frequent":
                fill_values[c] = s.mode(dropna=True).iloc[0] if s.notna().any() else fill_value
            elif categorical_strategy == "constant":
                fill_values[c] = fill_value
            else:
                raise ValueError(f"Unsupported categorical_strategy: {categorical_strategy}")

        return ImputerArtifacts(fill_values=fill_values, indicator_cols=indicator_cols)

    @staticmethod
    def transform_imputer(df: pd.DataFrame, art: ImputerArtifacts) -> pd.DataFrame:
        out = df.copy()
        for c in art.indicator_cols:
            if c in out.columns:
                out[f"{c}__is_missing"] = out[c].isna().astype(int)
        for c, v in art.fill_values.items():
            if c in out.columns:
                out[c] = out[c].fillna(v)
        return out

    # =========================
    # Rare categories
    # =========================

    @staticmethod
    def fit_rare_category_grouper(df: pd.DataFrame, cols: Sequence[str], min_freq: int, rare_token: str) -> RareCategoryArtifacts:
        keep_values: Dict[str, set] = {}
        for c in cols:
            vc = df[c].value_counts(dropna=False)
            keep_values[c] = set(vc[vc >= min_freq].index.tolist())
        return RareCategoryArtifacts(cols=list(cols), min_freq=min_freq, rare_token=rare_token, keep_values=keep_values)

    @staticmethod
    def transform_rare_category_grouper(df: pd.DataFrame, art: RareCategoryArtifacts) -> pd.DataFrame:
        out = df.copy()
        for c in art.cols:
            if c in out.columns:
                keep = art.keep_values.get(c, set())
                out[c] = out[c].where(out[c].isin(keep), other=art.rare_token)
        return out

    # =========================
    # Outliers
    # =========================

    @staticmethod
    def fit_outlier_clipper(df: pd.DataFrame, cols: Sequence[str], method: str, low_q: float, high_q: float, iqr_k: float) -> OutlierArtifacts:
        bounds: Dict[str, Tuple[float, float]] = {}
        for c in cols:
            s = pd.to_numeric(df[c], errors="coerce")
            if method == "quantile":
                lo = float(s.quantile(low_q))
                hi = float(s.quantile(high_q))
            elif method == "iqr":
                q1 = float(s.quantile(0.25))
                q3 = float(s.quantile(0.75))
                iqr = q3 - q1
                lo = q1 - iqr_k * iqr
                hi = q3 + iqr_k * iqr
            else:
                raise ValueError("method must be 'quantile' or 'iqr'")
            bounds[c] = (lo, hi)
        return OutlierArtifacts(cols=list(cols), bounds=bounds)

    @staticmethod
    def transform_outlier_clipper(df: pd.DataFrame, art: OutlierArtifacts) -> pd.DataFrame:
        out = df.copy()
        for c in art.cols:
            if c in out.columns:
                lo, hi = art.bounds[c]
                out[c] = pd.to_numeric(out[c], errors="coerce").clip(lower=lo, upper=hi)
        return out

    # =========================
    # Scaling
    # =========================

    @staticmethod
    def fit_scaler(df: pd.DataFrame, cols: Sequence[str], kind: str) -> ScalerArtifacts:
        if kind == "standard":
            scaler = StandardScaler()
        elif kind == "minmax":
            scaler = MinMaxScaler()
        elif kind == "robust":
            scaler = RobustScaler()
        else:
            raise ValueError("kind must be 'standard'|'minmax'|'robust'")
        scaler.fit(df.loc[:, cols].values)
        return ScalerArtifacts(cols=list(cols), kind=kind, scaler=scaler)

    @staticmethod
    def transform_scaler(df: pd.DataFrame, art: ScalerArtifacts) -> pd.DataFrame:
        out = df.copy()
        out.loc[:, art.cols] = art.scaler.transform(out.loc[:, art.cols].values)
        return out

    # =========================
    # Encoding: OneHot/Ordinal/Freq/Target
    # =========================

    @staticmethod
    def fit_onehot(df: pd.DataFrame, cols: Sequence[str], handle_unknown: str = "ignore") -> OneHotArtifacts:
        enc = FeatureEngineering._make_onehot_encoder(handle_unknown=handle_unknown)
        X = df.loc[:, cols].astype(str)
        enc.fit(X)
        names = enc.get_feature_names_out(cols).tolist()
        return OneHotArtifacts(cols=list(cols), encoder=enc, feature_names=names)

    @staticmethod
    def transform_onehot(df: pd.DataFrame, art: OneHotArtifacts) -> pd.DataFrame:
        X = df.loc[:, art.cols].astype(str)
        Xt = art.encoder.transform(X)
        return pd.DataFrame(Xt, columns=art.feature_names, index=df.index)

    @staticmethod
    def fit_ordinal(df: pd.DataFrame, cols: Sequence[str], unknown_value: int = -1) -> OrdinalArtifacts:
        enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=unknown_value)
        enc.fit(df.loc[:, cols])
        return OrdinalArtifacts(cols=list(cols), encoder=enc)

    @staticmethod
    def transform_ordinal(df: pd.DataFrame, art: OrdinalArtifacts) -> pd.DataFrame:
        Xt = art.encoder.transform(df.loc[:, art.cols])
        return pd.DataFrame(Xt, columns=art.cols, index=df.index)

    @staticmethod
    def fit_frequency(df: pd.DataFrame, col: str, default_count: int, default_freq: float) -> FrequencyArtifacts:
        vc = df[col].value_counts(dropna=False)
        count_map = {k: int(v) for k, v in vc.to_dict().items()}
        total = len(df)
        freq_map = {k: float(v / total) for k, v in vc.to_dict().items()}
        return FrequencyArtifacts(col=col, count_map=count_map, freq_map=freq_map, default_count=default_count, default_freq=default_freq)

    @staticmethod
    def transform_frequency(df: pd.DataFrame, art: FrequencyArtifacts) -> pd.DataFrame:
        out = df.copy()
        out[f"{art.col}_count"] = out[art.col].map(art.count_map).fillna(art.default_count).astype(float)
        out[f"{art.col}_freq"] = out[art.col].map(art.freq_map).fillna(art.default_freq).astype(float)
        return out

    @staticmethod
    def _fit_target_mapping(df: pd.DataFrame, y: Union[pd.Series, np.ndarray], te: TargetEncodingArtifacts) -> TargetEncodingArtifacts:
        yser = pd.Series(y).reset_index(drop=True)
        x = df[te.col].reset_index(drop=True)
        te.global_mean = float(yser.mean())
        stats = yser.groupby(x).agg(["mean", "count"])
        smooth = (stats["count"] * stats["mean"] + te.smoothing * te.global_mean) / (stats["count"] + te.smoothing)
        te.mapping = smooth.to_dict()
        return te

    @staticmethod
    def _oof_target_encode(df: pd.DataFrame, y: Union[pd.Series, np.ndarray], te: TargetEncodingArtifacts) -> pd.Series:
        yser = pd.Series(y).reset_index(drop=True)
        x = df[te.col].reset_index(drop=True)
        global_mean = float(yser.mean())

        if te.cv_kind == "kfold":
            splitter = KFold(n_splits=te.n_splits, shuffle=True, random_state=42)
            splits = splitter.split(x)
            oof = pd.Series(index=x.index, dtype=float)
            for tr, va in splits:
                x_tr, y_tr = x.iloc[tr], yser.iloc[tr]
                stats = y_tr.groupby(x_tr).agg(["mean", "count"])
                smooth = (stats["count"] * stats["mean"] + te.smoothing * global_mean) / (stats["count"] + te.smoothing)
                oof.iloc[va] = x.iloc[va].map(smooth).fillna(global_mean)
            return oof.rename(f"{te.col}_te")

        if te.cv_kind == "groupkfold":
            if not te.group_col:
                raise ValueError("group_col required for groupkfold")
            groups = df[te.group_col].reset_index(drop=True)
            splitter = GroupKFold(n_splits=te.n_splits)
            splits = splitter.split(x, yser, groups=groups)
            oof = pd.Series(index=x.index, dtype=float)
            for tr, va in splits:
                x_tr, y_tr = x.iloc[tr], yser.iloc[tr]
                stats = y_tr.groupby(x_tr).agg(["mean", "count"])
                smooth = (stats["count"] * stats["mean"] + te.smoothing * global_mean) / (stats["count"] + te.smoothing)
                oof.iloc[va] = x.iloc[va].map(smooth).fillna(global_mean)
            return oof.rename(f"{te.col}_te")

        if te.cv_kind == "timeseries":
            if not te.time_col:
                raise ValueError("time_col required for timeseries")
            order = pd.to_datetime(df[te.time_col], errors="coerce").sort_values().index
            x_sorted = x.loc[order].reset_index(drop=True)
            y_sorted = yser.loc[order].reset_index(drop=True)

            tss = TimeSeriesSplit(n_splits=te.n_splits)
            oof_sorted = pd.Series(index=np.arange(len(x_sorted)), dtype=float)
            for tr, va in tss.split(x_sorted):
                stats = y_sorted.iloc[tr].groupby(x_sorted.iloc[tr]).agg(["mean", "count"])
                smooth = (stats["count"] * stats["mean"] + te.smoothing * global_mean) / (stats["count"] + te.smoothing)
                oof_sorted.iloc[va] = x_sorted.iloc[va].map(smooth).fillna(global_mean)

            oof = pd.Series(index=df.index, dtype=float)
            oof.loc[order] = oof_sorted.values
            return oof.rename(f"{te.col}_te")

        raise ValueError("cv_kind must be 'kfold'|'groupkfold'|'timeseries'")

    @staticmethod
    def transform_target_inference(df: pd.DataFrame, te: TargetEncodingArtifacts) -> pd.Series:
        return df[te.col].map(te.mapping).fillna(te.global_mean).astype(float).rename(f"{te.col}_te")

    # =========================
    # Log / Power / Binning / Polynomial
    # =========================

    @staticmethod
    def fit_log(cols: List[str], suffix: str, clip_lower: float) -> LogArtifacts:
        return LogArtifacts(cols=cols, suffix=suffix, clip_lower=clip_lower)

    @staticmethod
    def transform_log(df: pd.DataFrame, art: LogArtifacts) -> pd.DataFrame:
        out = df.copy()
        for c in art.cols:
            FeatureEngineering._validate_cols_exist(out, [c], what="log cols")
            out[c + art.suffix] = np.log1p(pd.to_numeric(out[c], errors="coerce").clip(lower=art.clip_lower))
        return out

    @staticmethod
    def fit_power(df: pd.DataFrame, cols: List[str], method: str, standardize: bool) -> PowerTransformArtifacts:
        FeatureEngineering._validate_cols_exist(df, cols, what="power cols")
        pt = PowerTransformer(method=method, standardize=standardize)
        pt.fit(df.loc[:, cols].values)
        return PowerTransformArtifacts(cols=cols, transformer=pt)

    @staticmethod
    def transform_power(df: pd.DataFrame, art: PowerTransformArtifacts) -> pd.DataFrame:
        out = df.copy()
        out.loc[:, art.cols] = art.transformer.transform(out.loc[:, art.cols].values)
        return out

    @staticmethod
    def fit_binning(df: pd.DataFrame, cols: List[str], n_bins: int, strategy: str, encode: str) -> BinningArtifacts:
        FeatureEngineering._validate_cols_exist(df, cols, what="binning cols")
        binner = KBinsDiscretizer(n_bins=n_bins, strategy=strategy, encode=encode)
        X = df.loc[:, cols].values
        binner.fit(X)
        out_dim = int(binner.transform(X[:1]).shape[1])
        feat_names = [f"bin_{i}" for i in range(out_dim)]
        return BinningArtifacts(cols=cols, binner=binner, feature_names=feat_names)

    @staticmethod
    def transform_binning(df: pd.DataFrame, art: BinningArtifacts) -> pd.DataFrame:
        Xt = art.binner.transform(df.loc[:, art.cols].values)
        return pd.DataFrame(Xt, columns=art.feature_names, index=df.index)

    @staticmethod
    def fit_polynomial(df: pd.DataFrame, cols: List[str], degree: int, include_bias: bool, interaction_only: bool, drop_original: bool) -> PolynomialArtifacts:
        FeatureEngineering._validate_cols_exist(df, cols, what="polynomial cols")
        poly = PolynomialFeatures(degree=degree, include_bias=include_bias, interaction_only=interaction_only)
        poly.fit(df.loc[:, cols].values)
        feat_names = poly.get_feature_names_out(cols).tolist()
        return PolynomialArtifacts(cols=cols, poly=poly, feature_names=feat_names, drop_original=drop_original)

    @staticmethod
    def transform_polynomial(df: pd.DataFrame, art: PolynomialArtifacts) -> pd.DataFrame:
        Xt = art.poly.transform(df.loc[:, art.cols].values)
        poly_df = pd.DataFrame(Xt, columns=art.feature_names, index=df.index)
        out = df.copy()
        if art.drop_original:
            out = out.drop(columns=art.cols, errors="ignore")
        out = pd.concat([out, poly_df], axis=1)
        return out

    # =========================
    # Time features
    # =========================

    @staticmethod
    def fit_time_calendar(ts_col: str, prefix: Optional[str], drop_original: bool) -> TimeCalendarArtifacts:
        pre = prefix or f"{ts_col}_"
        return TimeCalendarArtifacts(ts_col=ts_col, prefix=pre, drop_original=drop_original)

    @staticmethod
    def transform_time_calendar(df: pd.DataFrame, art: TimeCalendarArtifacts) -> pd.DataFrame:
        out = df.copy()
        FeatureEngineering._validate_cols_exist(out, [art.ts_col], what="time_calendar ts_col")
        ts = pd.to_datetime(out[art.ts_col], errors="coerce")
        pre = art.prefix
        out[pre + "hour"] = ts.dt.hour
        out[pre + "dayofweek"] = ts.dt.dayofweek
        out[pre + "month"] = ts.dt.month
        out[pre + "day"] = ts.dt.day
        out[pre + "year"] = ts.dt.year
        out[pre + "is_weekend"] = (ts.dt.dayofweek >= 5).astype(int)
        if art.drop_original:
            out = out.drop(columns=[art.ts_col], errors="ignore")
        return out

    @staticmethod
    def fit_lag(group_cols: List[str], ts_col: str, value_col: str, lags: List[int], prefix: Optional[str]) -> LagArtifacts:
        pre = prefix or f"{value_col}_lag_"
        return LagArtifacts(group_cols=group_cols, ts_col=ts_col, value_col=value_col, lags=lags, prefix=pre)

    @staticmethod
    def transform_lag(df: pd.DataFrame, art: LagArtifacts) -> pd.DataFrame:
        out = df.copy().sort_values(art.group_cols + [art.ts_col])
        FeatureEngineering._validate_cols_exist(out, art.group_cols + [art.ts_col, art.value_col], what="lag inputs")
        for lag in art.lags:
            out[f"{art.prefix}{lag}"] = out.groupby(art.group_cols)[art.value_col].shift(lag)
        return out

    @staticmethod
    def fit_rolling(group_cols: List[str], ts_col: str, value_col: str, windows: List[int], stats: List[str],
                    shift: int, min_periods: int, prefix: Optional[str]) -> RollingArtifacts:
        pre = prefix or f"{value_col}_roll_"
        return RollingArtifacts(group_cols=group_cols, ts_col=ts_col, value_col=value_col, windows=windows, stats=stats,
                                shift=shift, min_periods=min_periods, prefix=pre)

    @staticmethod
    def transform_rolling(df: pd.DataFrame, art: RollingArtifacts) -> pd.DataFrame:
        out = df.copy().sort_values(art.group_cols + [art.ts_col])
        FeatureEngineering._validate_cols_exist(out, art.group_cols + [art.ts_col, art.value_col], what="rolling inputs")

        base = out.groupby(art.group_cols)[art.value_col].shift(art.shift)

        for w in art.windows:
            roll = base.rolling(window=w, min_periods=art.min_periods)
            for s in art.stats:
                if not hasattr(roll, s):
                    raise ValueError(f"Unsupported rolling stat '{s}'")
                out[f"{art.prefix}{w}_{s}"] = getattr(roll, s)().reset_index(level=list(range(len(art.group_cols))), drop=True)
        return out

    # =========================
    # Domain features
    # =========================

    @staticmethod
    def fit_ratio(numerator: str, denominator: str, out_col: str, eps: float) -> DomainRatioArtifacts:
        return DomainRatioArtifacts(numerator=numerator, denominator=denominator, out_col=out_col, eps=eps)

    @staticmethod
    def transform_ratio(df: pd.DataFrame, art: DomainRatioArtifacts) -> pd.DataFrame:
        out = df.copy()
        FeatureEngineering._validate_cols_exist(out, [art.numerator, art.denominator], what="ratio inputs")
        denom = pd.to_numeric(out[art.denominator], errors="coerce")
        out[art.out_col] = pd.to_numeric(out[art.numerator], errors="coerce") / (denom.replace(0.0, np.nan) + art.eps)
        return out

    @staticmethod
    def fit_diff(a: str, b: str, out_col: str) -> DomainDiffArtifacts:
        return DomainDiffArtifacts(a=a, b=b, out_col=out_col)

    @staticmethod
    def transform_diff(df: pd.DataFrame, art: DomainDiffArtifacts) -> pd.DataFrame:
        out = df.copy()
        FeatureEngineering._validate_cols_exist(out, [art.a, art.b], what="diff inputs")
        out[art.out_col] = pd.to_numeric(out[art.a], errors="coerce") - pd.to_numeric(out[art.b], errors="coerce")
        return out

    # =========================
    # Multicollinearity
    # =========================

    @staticmethod
    def fit_multicollinearity_corr_selector(df_numeric: pd.DataFrame, threshold: float = 0.90, method: str = "pearson") -> MulticollinearityArtifacts:
        cols = list(df_numeric.columns)
        if len(cols) <= 1:
            return MulticollinearityArtifacts(method="corr", threshold=threshold, selected_cols=cols, dropped_cols=[])
        corr = df_numeric.corr(method=method).abs()
        upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
        dropped = [c for c in upper.columns if (upper[c] > threshold).any()]
        selected = [c for c in cols if c not in dropped]
        return MulticollinearityArtifacts(method="corr", threshold=threshold, selected_cols=selected, dropped_cols=dropped)

    @staticmethod
    def transform_multicollinearity_selector(df: pd.DataFrame, art: MulticollinearityArtifacts) -> pd.DataFrame:
        keep = [c for c in art.selected_cols if c in df.columns]
        other = [c for c in df.columns if c not in art.selected_cols and c not in art.dropped_cols]
        return df.loc[:, other + keep]

    # =========================
    # Importance / VIF
    # =========================

    @staticmethod
    def permutation_importance_df(model, X: pd.DataFrame, y: Union[pd.Series, np.ndarray], scoring: Optional[str] = None, n_repeats: int = 10, random_state: int = 42) -> pd.DataFrame:
        res = permutation_importance(model, X, y, scoring=scoring, n_repeats=n_repeats, random_state=random_state)
        return (
            pd.DataFrame({
                "feature": X.columns,
                "importance_mean": res.importances_mean,
                "importance_std": res.importances_std,
            })
            .sort_values("importance_mean", ascending=False)
            .reset_index(drop=True)
        )

    @staticmethod
    def compute_vif(df: pd.DataFrame, cols: Sequence[str], add_constant: bool = True) -> pd.DataFrame:
        if not _HAS_STATSMODELS:
            raise ImportError("statsmodels is required for VIF. Install: pip install statsmodels")
        FeatureEngineering._validate_cols_exist(df, cols)

        X = df.loc[:, cols].dropna().copy()
        nunique = X.nunique(dropna=False)
        X = X.drop(columns=nunique[nunique <= 1].index.tolist(), errors="ignore")

        if add_constant:
            X = sm.add_constant(X, has_constant="add")

        rows = []
        for i, col in enumerate(X.columns):
            if col == "const":
                continue
            rows.append((col, float(variance_inflation_factor(X.values, i))))
        return pd.DataFrame(rows, columns=["feature", "vif"]).sort_values("vif", ascending=False)

    # =========================
    # FIT PIPELINE
    # =========================

    @staticmethod
    def fit_pipeline(df: pd.DataFrame, y: Optional[Union[pd.Series, np.ndarray]], pipeline: PipelineSpec) -> PipelineArtifacts:
        schema: Optional[SchemaArtifacts] = None
        columns: Optional[ColumnArtifacts] = None

        imputer: Optional[ImputerArtifacts] = None
        rare: Optional[RareCategoryArtifacts] = None
        outliers: Optional[OutlierArtifacts] = None
        scaler: Optional[ScalerArtifacts] = None

        encoding_type: Optional[str] = None
        encoding_cols: List[str] = []
        onehot: Optional[OneHotArtifacts] = None
        ordinal: Optional[OrdinalArtifacts] = None
        frequency: Optional[List[FrequencyArtifacts]] = None
        target: Optional[List[TargetEncodingArtifacts]] = None
        drop_original_cats = True

        log_art: Optional[LogArtifacts] = None
        power_art: Optional[PowerTransformArtifacts] = None
        bin_art: Optional[BinningArtifacts] = None
        poly_art: Optional[PolynomialArtifacts] = None
        time_cal_art: Optional[TimeCalendarArtifacts] = None
        lag_arts: List[LagArtifacts] = []
        roll_arts: List[RollingArtifacts] = []
        ratio_arts: List[DomainRatioArtifacts] = []
        diff_arts: List[DomainDiffArtifacts] = []

        multicol: Optional[MulticollinearityArtifacts] = None
        multicol_params: Optional[Dict[str, Any]] = None

        work = df.copy()

        # Drop columns that contain all missing values
        all_missing_cols = work.columns[work.isna().all()].tolist()
        
        if all_missing_cols:
            print(f"Dropping columns with all missing values: {all_missing_cols}")
            work = work.drop(columns=all_missing_cols)

        for step in pipeline._steps:
            st = step["type"]

            if st == "schema":
                if step.get("enforce", True):
                    schema = FeatureEngineering.fit_schema(work)

            elif st == "infer_columns":
                columns = FeatureEngineering._infer_columns(work)

            elif st == "impute":
                if columns is None:
                    columns = FeatureEngineering._infer_columns(work)
                imputer = FeatureEngineering.fit_imputer(
                    work,
                    columns.numeric_cols,
                    columns.categorical_cols,
                    numeric_strategy=step["numeric_strategy"],
                    categorical_strategy=step["categorical_strategy"],
                    fill_value=step["fill_value"],
                    add_indicator=step["add_missing_indicators"],
                )
                work = FeatureEngineering.transform_imputer(work, imputer)

            elif st == "rare":
                if columns is None:
                    columns = FeatureEngineering._infer_columns(work)
                if columns.categorical_cols:
                    rare = FeatureEngineering.fit_rare_category_grouper(work, columns.categorical_cols, step["min_freq"], step["rare_token"])
                    work = FeatureEngineering.transform_rare_category_grouper(work, rare)

            elif st == "outliers":
                if columns is None:
                    columns = FeatureEngineering._infer_columns(work)
                cols = step.get("cols") or columns.numeric_cols
                outliers = FeatureEngineering.fit_outlier_clipper(work, cols, step["method"], step["low_q"], step["high_q"], step["iqr_k"])
                work = FeatureEngineering.transform_outlier_clipper(work, outliers)

            elif st == "scale":
                if columns is None:
                    columns = FeatureEngineering._infer_columns(work)
                cols = step.get("cols") or columns.numeric_cols
                scaler = FeatureEngineering.fit_scaler(work, cols, step["kind"])
                work = FeatureEngineering.transform_scaler(work, scaler)

            elif st == "log1p":
                log_art = FeatureEngineering.fit_log(step["cols"], step["suffix"], step["clip_lower"])
                work = FeatureEngineering.transform_log(work, log_art)

            elif st == "power":
                power_art = FeatureEngineering.fit_power(work, step["cols"], step["method"], step["standardize"])
                work = FeatureEngineering.transform_power(work, power_art)

            elif st == "binning":
                bin_art = FeatureEngineering.fit_binning(work, step["cols"], step["n_bins"], step["strategy"], step["encode"])
                # binning produces a new DF later during transform; do not apply here (to keep consistent assembly)
                # (We fit on current work, but don't append now to avoid double counting during fit)
                # We'll append during transform.
                # So do nothing to 'work' here.

            elif st == "polynomial":
                poly_art = FeatureEngineering.fit_polynomial(work, step["cols"], step["degree"], step["include_bias"], step["interaction_only"], step["drop_original"])
                work = FeatureEngineering.transform_polynomial(work, poly_art)

            elif st == "time_calendar":
                time_cal_art = FeatureEngineering.fit_time_calendar(step["ts_col"], step["prefix"], step["drop_original"])
                work = FeatureEngineering.transform_time_calendar(work, time_cal_art)

            elif st == "lags":
                la = FeatureEngineering.fit_lag(step["group_cols"], step["ts_col"], step["value_col"], step["lags"], step.get("prefix"))
                lag_arts.append(la)
                work = FeatureEngineering.transform_lag(work, la)

            elif st == "rolling":
                ra = FeatureEngineering.fit_rolling(step["group_cols"], step["ts_col"], step["value_col"], step["windows"], step["stats"], step["shift"], step["min_periods"], step.get("prefix"))
                roll_arts.append(ra)
                work = FeatureEngineering.transform_rolling(work, ra)

            elif st == "ratio":
                r = FeatureEngineering.fit_ratio(step["numerator"], step["denominator"], step["out_col"], step["eps"])
                ratio_arts.append(r)
                work = FeatureEngineering.transform_ratio(work, r)

            elif st == "diff":
                d = FeatureEngineering.fit_diff(step["a"], step["b"], step["out_col"])
                diff_arts.append(d)
                work = FeatureEngineering.transform_diff(work, d)

            elif st.startswith("encode_"):
                if columns is None:
                    columns = FeatureEngineering._infer_columns(work)
                drop_original_cats = bool(step.get("drop_original", True))

                if st == "encode_onehot":
                    encoding_type = "onehot"
                    encoding_cols = step.get("cols") or columns.categorical_cols
                    if encoding_cols:
                        onehot = FeatureEngineering.fit_onehot(work, encoding_cols, step["handle_unknown"])

                elif st == "encode_ordinal":
                    encoding_type = "ordinal"
                    encoding_cols = step.get("cols") or columns.categorical_cols
                    if encoding_cols:
                        ordinal = FeatureEngineering.fit_ordinal(work, encoding_cols, step["unknown_value"])

                elif st == "encode_frequency":
                    encoding_type = "frequency"
                    encoding_cols = step.get("cols") or columns.categorical_cols
                    frequency = []
                    for c in encoding_cols:
                        frequency.append(FeatureEngineering.fit_frequency(work, c, step["default_count"], step["default_freq"]))

                elif st == "encode_target":
                    if y is None:
                        raise ValueError("y is required for target encoding")
                    encoding_type = "target"
                    encoding_cols = step.get("cols") or columns.categorical_cols
                    target = []
                    for c in encoding_cols:
                        te = TargetEncodingArtifacts(
                            col=c,
                            smoothing=float(step["smoothing"]),
                            n_splits=int(step["n_splits"]),
                            cv_kind=str(step["cv_kind"]),
                            group_col=step.get("group_col"),
                            time_col=step.get("time_col"),
                        )
                        te = FeatureEngineering._fit_target_mapping(work, y, te)
                        target.append(te)
                else:
                    raise ValueError(f"Unknown encoding step: {st}")

            elif st == "multicollinearity_corr":
                multicol_params = {"threshold": float(step["threshold"]), "cols": step.get("cols")}
                # fit later after we can compute final feature matrix

            else:
                raise ValueError(f"Unknown step type: {st}")

        if columns is None:
            columns = FeatureEngineering._infer_columns(work)

        art = PipelineArtifacts(
            pipeline=pipeline,
            schema=schema,
            columns=columns,
            imputer=imputer,
            rare=rare,
            outliers=outliers,
            scaler=scaler,
            encoding_type=encoding_type,
            encoding_cols=encoding_cols,
            onehot=onehot,
            ordinal=ordinal,
            frequency=frequency,
            target=target,
            log=log_art,
            power=power_art,
            binning=bin_art,
            polynomial=poly_art,
            time_calendar=time_cal_art,
            lags=lag_arts or None,
            rolling=roll_arts or None,
            ratios=ratio_arts or None,
            diffs=diff_arts or None,
            multicollinearity=None,
            drop_original_categoricals_after_encoding=drop_original_cats,
        )

        # Fit multicollinearity using preview of TRAIN features
        if multicol_params is not None:
            preview = FeatureEngineering.transform_pipeline(df, art, y=y, is_train=(encoding_type == "target"))
            mc_cols = multicol_params["cols"] or preview.select_dtypes(include="number").columns.tolist()
            mc_cols = [c for c in mc_cols if c in preview.columns]
            if mc_cols:
                multicol = FeatureEngineering.fit_multicollinearity_corr_selector(preview.loc[:, mc_cols], threshold=multicol_params["threshold"])
            art.multicollinearity = multicol

        return art

    # =========================
    # TRANSFORM PIPELINE
    # =========================

    @staticmethod
    def transform_pipeline(df: pd.DataFrame, art: PipelineArtifacts, *, y: Optional[Union[pd.Series, np.ndarray]] = None, is_train: bool = False) -> pd.DataFrame:
        if art.schema is not None:
            FeatureEngineering.validate_schema(df, art.schema, strict_extra=False)

        out = df.copy()
        # Drop columns that contain all missing values
        all_missing_cols = out.columns[out.isna().all()].tolist()

        if all_missing_cols:
            print(f"Dropping columns with all missing values: {all_missing_cols}")
            out = out.drop(columns=all_missing_cols)

        # Apply FE steps that modify raw columns first (log/power/poly/time/lag/rolling/ratio/diff)
        if art.imputer is not None:
            out = FeatureEngineering.transform_imputer(out, art.imputer)

        if art.rare is not None:
            out = FeatureEngineering.transform_rare_category_grouper(out, art.rare)

        if art.outliers is not None:
            out = FeatureEngineering.transform_outlier_clipper(out, art.outliers)

        if art.scaler is not None:
            out = FeatureEngineering.transform_scaler(out, art.scaler)

        if art.log is not None:
            out = FeatureEngineering.transform_log(out, art.log)

        if art.power is not None:
            out = FeatureEngineering.transform_power(out, art.power)

        if art.time_calendar is not None:
            out = FeatureEngineering.transform_time_calendar(out, art.time_calendar)

        if art.ratios is not None:
            for r in art.ratios:
                out = FeatureEngineering.transform_ratio(out, r)

        if art.diffs is not None:
            for d in art.diffs:
                out = FeatureEngineering.transform_diff(out, d)

        if art.lags is not None:
            for la in art.lags:
                out = FeatureEngineering.transform_lag(out, la)

        if art.rolling is not None:
            for ra in art.rolling:
                out = FeatureEngineering.transform_rolling(out, ra)

        if art.polynomial is not None:
            out = FeatureEngineering.transform_polynomial(out, art.polynomial)

        # Assemble final matrix: numeric + encoded + binning output (optional)
        numeric_part = out.select_dtypes(include="number")
        encoded_parts: List[pd.DataFrame] = []

        # Binning adds separate numeric features
        if art.binning is not None:
            encoded_parts.append(FeatureEngineering.transform_binning(out, art.binning))

        et = art.encoding_type
        cols = art.encoding_cols

        if et == "onehot" and art.onehot is not None and cols:
            encoded_parts.append(FeatureEngineering.transform_onehot(out, art.onehot))

        elif et == "ordinal" and art.ordinal is not None and cols:
            encoded_parts.append(FeatureEngineering.transform_ordinal(out, art.ordinal))

        elif et == "frequency" and art.frequency is not None and cols:
            tmp = out.copy()
            new_cols: List[str] = []
            for fa in art.frequency:
                tmp = FeatureEngineering.transform_frequency(tmp, fa)
                new_cols.extend([f"{fa.col}_count", f"{fa.col}_freq"])
            encoded_parts.append(tmp.loc[:, new_cols])

        elif et == "target" and cols:
            if is_train:
                if y is None:
                    raise ValueError("y required for is_train=True with target encoding (OOF)")
                tmp = out.copy()
                te_cols: List[str] = []
                if not art.target:
                    raise ValueError("TargetEncodingArtifacts missing")
                for te in art.target:
                    oof = FeatureEngineering._oof_target_encode(tmp, y, te)
                    tmp[oof.name] = oof.values
                    te_cols.append(oof.name)
                encoded_parts.append(tmp.loc[:, te_cols])
            else:
                tmp = out.copy()
                te_cols: List[str] = []
                if not art.target:
                    raise ValueError("TargetEncodingArtifacts missing")
                for te in art.target:
                    s = FeatureEngineering.transform_target_inference(tmp, te)
                    tmp[s.name] = s
                    te_cols.append(s.name)
                encoded_parts.append(tmp.loc[:, te_cols])

        final = numeric_part if not encoded_parts else pd.concat([numeric_part] + encoded_parts, axis=1)

        # Apply multicollinearity selector
        if art.multicollinearity is not None:
            final = FeatureEngineering.transform_multicollinearity_selector(final, art.multicollinearity)

        # Keep raw categoricals if requested
        if not art.drop_original_categoricals_after_encoding and cols:
            final = pd.concat([final, out.loc[:, cols]], axis=1)

        return final

    # =========================
    # Save / Load
    # =========================

    @staticmethod
    def save_artifacts(art: PipelineArtifacts, path: str) -> None:
        joblib.dump(art, path)

    @staticmethod
    def load_artifacts(path: str) -> PipelineArtifacts:
        return joblib.load(path)


# -----------------------------
# Example usage (XGBoost)
# -----------------------------
if __name__ == "__main__":
    import xgboost as xgb
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score

    df = pd.DataFrame({
        "user_id": [1, 1, 1, 2, 2, 3, 3, 3],
        "event_time": pd.date_range("2025-01-01", periods=8, freq="D"),
        "age": [10, 20, None, 40, 50, 60, 70, 80],
        "income": [100, None, 200, 300, 5000, 6000, 7000, 8000],
        "city": ["A", "A", "B", "C", "Z", "Z", "A", "B"],
        "target": [0, 1, 0, 1, 1, 0, 1, 0],
    })

    y = df["target"].values
    X = df.drop(columns=["target"])

    pipeline = (
        FeatureEngineering.Pipeline()
        .schema(enforce=True)
        .infer_columns()
        .impute(add_missing_indicators=True)
        .rare_categories(min_freq=2)
        .outliers(method="quantile", low_q=0.01, high_q=0.99)
        .add_log1p(cols=["income"])
        .power_transform(cols=["age"], method="yeo-johnson", standardize=True)
        .binning(cols=["age"], n_bins=4, strategy="quantile")
        .polynomial(cols=["age", "income"], degree=2, interaction_only=True)
        .time_calendar(ts_col="event_time", drop_original=False)
        .add_lags(group_cols=["user_id"], ts_col="event_time", value_col="income", lags=[1, 2])
        .add_rolling(group_cols=["user_id"], ts_col="event_time", value_col="income", windows=[2, 3], stats=["mean"])
        .add_ratio(numerator="income", denominator="age", out_col="income_per_age")
        .add_diff(a="income", b="age", out_col="income_minus_age")
        .encode_target(cols=["city"], smoothing=10.0, n_splits=3, cv_kind="kfold", drop_original=True)
        .multicollinearity_corr(threshold=0.90)
        .build()
    )

    art = FeatureEngineering.fit_pipeline(X, y, pipeline)

    X_all = FeatureEngineering.transform_pipeline(X, art, y=y, is_train=True)
    X_train, X_val, y_train, y_val = train_test_split(X_all, y, test_size=0.25, random_state=42, stratify=y)

    model = xgb.XGBClassifier(
        n_estimators=200,
        max_depth=4,
        learning_rate=0.1,
        subsample=0.9,
        colsample_bytree=0.9,
        tree_method="hist",
        eval_metric="auc",
        random_state=42,
    )
    model.fit(X_train, y_train)

    pred = model.predict_proba(X_val)[:, 1]
    print("AUC:", roc_auc_score(y_val, pred))

    FeatureEngineering.save_artifacts(art, "full_pipeline_artifacts.joblib")
    art2 = FeatureEngineering.load_artifacts("full_pipeline_artifacts.joblib")
    X_inf = FeatureEngineering.transform_pipeline(X, art2, is_train=False)
    print("Inference shape:", X_inf.shape)
