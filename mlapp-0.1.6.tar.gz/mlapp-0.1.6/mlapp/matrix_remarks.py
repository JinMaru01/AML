# ADD THIS BELOW your Metrics class (in metrics_utils.py)

from dataclasses import dataclass
from typing import Dict, Any, Optional
import numpy as np
import pandas as pd


@dataclass
class Remark:
    status: str        # "good" | "warning" | "bad" | "na"
    message: str
    value: Optional[float] = None


class Remarks:
    """
    Generate human-friendly remarks for each metric/table.

    Default thresholds are generic. In production, you should tune them
    to your business KPI / class imbalance / baseline performance.
    """

    # -----------------------
    # Generic helpers
    # -----------------------

    @staticmethod
    def _status_by_threshold(value: Optional[float], good: float, warn: float, higher_is_better: bool = True) -> Remark:
        if value is None or (isinstance(value, float) and not np.isfinite(value)):
            return Remark("na", "Not available", value=None)

        v = float(value)
        if higher_is_better:
            if v >= good:
                return Remark("good", f"Good (>= {good}).", v)
            if v >= warn:
                return Remark("warning", f"Acceptable but watch (>= {warn}).", v)
            return Remark("bad", f"Poor (< {warn}).", v)
        else:
            if v <= good:
                return Remark("good", f"Good (<= {good}).", v)
            if v <= warn:
                return Remark("warning", f"Acceptable but watch (<= {warn}).", v)
            return Remark("bad", f"Poor (> {warn}).", v)

    # -----------------------
    # Classification metric remarks
    # -----------------------

    @staticmethod
    def accuracy_remark(acc: Optional[float]) -> Remark:
        # Very generic defaults
        return Remarks._status_by_threshold(acc, good=0.85, warn=0.75, higher_is_better=True)

    @staticmethod
    def f1_remark(f1: Optional[float]) -> Remark:
        return Remarks._status_by_threshold(f1, good=0.80, warn=0.65, higher_is_better=True)

    @staticmethod
    def auc_remark(auc: Optional[float]) -> Remark:
        return Remarks._status_by_threshold(auc, good=0.80, warn=0.70, higher_is_better=True)

    @staticmethod
    def ap_remark(ap: Optional[float]) -> Remark:
        return Remarks._status_by_threshold(ap, good=0.70, warn=0.50, higher_is_better=True)

    @staticmethod
    def logloss_remark(ll: Optional[float]) -> Remark:
        # lower is better (depends strongly on problem)
        return Remarks._status_by_threshold(ll, good=0.40, warn=0.70, higher_is_better=False)

    @staticmethod
    def brier_remark(brier: Optional[float]) -> Remark:
        # lower is better; typical range 0..0.25 for binary with decent calibration
        return Remarks._status_by_threshold(brier, good=0.15, warn=0.22, higher_is_better=False)

    @staticmethod
    def ks_remark(ks: Optional[float]) -> Remark:
        # KS > 0.3 often considered decent in many credit-risk like problems
        return Remarks._status_by_threshold(ks, good=0.35, warn=0.25, higher_is_better=True)

    @staticmethod
    def gini_remark(gini: Optional[float]) -> Remark:
        # gini = 2*AUC-1 => good if AUC good
        return Remarks._status_by_threshold(gini, good=0.60, warn=0.40, higher_is_better=True)

    # -----------------------
    # Confusion matrix remarks
    # -----------------------

    @staticmethod
    def confusion_matrix_remark(cm: Optional[np.ndarray]) -> Remark:
        """
        For binary only: checks if model collapses to one class or extreme skew.
        """
        if cm is None:
            return Remark("na", "Not available", None)

        cm = np.asarray(cm)
        if cm.shape != (2, 2):
            return Remark("na", "Confusion-matrix remark supported for binary only.", None)

        tn, fp, fn, tp = cm.ravel()
        total = tn + fp + fn + tp
        if total == 0:
            return Remark("na", "Empty confusion matrix.", None)

        # collapse checks
        predicted_pos = tp + fp
        predicted_neg = tn + fn

        if predicted_pos == 0 or predicted_neg == 0:
            return Remark("bad", "Model predicts only one class (collapsed). Check threshold / imbalance.", None)

        # If one error type dominates heavily
        fn_rate = fn / max(fn + tp, 1)
        fp_rate = fp / max(fp + tn, 1)

        if fn_rate > 0.50 or fp_rate > 0.50:
            return Remark("warning", "High error rate for one class. Consider threshold tuning / class weights.", None)

        return Remark("good", "Confusion matrix looks balanced enough (not collapsed).", None)

    # -----------------------
    # Calibration remarks
    # -----------------------

    @staticmethod
    def calibration_remark(calib_df: Optional[pd.DataFrame]) -> Remark:
        """
        Simple calibration quality using mean absolute gap between prob_true and prob_pred.
        Smaller gap is better.
        """
        if calib_df is None or len(calib_df) == 0:
            return Remark("na", "Calibration curve not available.", None)

        df = calib_df.copy()
        if not {"prob_pred", "prob_true"}.issubset(df.columns):
            return Remark("na", "Calibration curve format invalid.", None)

        gap = float(np.mean(np.abs(df["prob_true"] - df["prob_pred"])))
        # lower is better
        if gap <= 0.03:
            return Remark("good", "Well-calibrated probabilities (avg gap <= 0.03).", gap)
        if gap <= 0.07:
            return Remark("warning", "Calibration is okay but could be improved (gap <= 0.07).", gap)
        return Remark("bad", "Poor calibration (gap > 0.07). Consider calibration (Platt/Isotonic).", gap)

    # -----------------------
    # Lift/Gain + Deciles remarks
    # -----------------------

    @staticmethod
    def lift_gain_remark(table: Optional[pd.DataFrame]) -> Remark:
        """
        Evaluate top-decile lift and overall KS from the lift/gain table.
        """
        if table is None or len(table) == 0:
            return Remark("na", "Lift/Gain table not available.", None)

        df = table.copy()
        if "lift" not in df.columns or "ks_overall" not in df.columns:
            return Remark("na", "Lift/Gain table format invalid.", None)

        # top bin is bin=1 (highest scores) in our table
        top_lift = float(df.loc[df["bin"] == df["bin"].min(), "lift"].iloc[0])
        ks_overall = float(df["ks_overall"].max())

        # Generic heuristics:
        # top-decile lift > 2 is usually good, 1.5 moderate
        # KS overall > 0.3 decent
        if top_lift >= 2.0 and ks_overall >= 0.30:
            return Remark("good", f"Strong ranking power (top lift={top_lift:.2f}, KS={ks_overall:.2f}).", top_lift)
        if top_lift >= 1.5 and ks_overall >= 0.20:
            return Remark("warning", f"Moderate ranking power (top lift={top_lift:.2f}, KS={ks_overall:.2f}).", top_lift)
        return Remark("bad", f"Weak ranking power (top lift={top_lift:.2f}, KS={ks_overall:.2f}).", top_lift)

    # -----------------------
    # PSI remarks
    # -----------------------

    @staticmethod
    def psi_remark(psi: Optional[float]) -> Remark:
        if psi is None or (isinstance(psi, float) and not np.isfinite(psi)):
            return Remark("na", "PSI not available.", None)

        v = float(psi)
        # common rule of thumb
        if v < 0.10:
            return Remark("good", "No meaningful drift (PSI < 0.10).", v)
        if v < 0.20:
            return Remark("warning", "Moderate drift (0.10 <= PSI < 0.20). Monitor.", v)
        return Remark("bad", "Significant drift (PSI >= 0.20). Investigate data / retrain.", v)

    # -----------------------
    # Full remarks bundle
    # -----------------------

    @staticmethod
    def classification_remarks(rep) -> Dict[str, Dict[str, Any]]:
        """
        rep is ClassificationReport from Metrics.classification_report(...)
        Returns dict of metric -> remark dict (status/message/value).
        """
        out: Dict[str, Remark] = {}

        out["accuracy"] = Remarks.accuracy_remark(getattr(rep, "accuracy", None))

        # prefer weighted f1 if present
        f1_w = None
        if hasattr(rep, "f1") and isinstance(rep.f1, dict):
            f1_w = rep.f1.get("weighted") or rep.f1.get("macro") or rep.f1.get("micro")
        out["f1"] = Remarks.f1_remark(f1_w)

        out["auc"] = Remarks.auc_remark(getattr(rep, "auc_binary", None) or getattr(rep, "auc_multiclass_ovr_weighted", None))
        out["average_precision"] = Remarks.ap_remark(getattr(rep, "ap_binary", None) or getattr(rep, "ap_multiclass_ovr_weighted", None))

        out["logloss"] = Remarks.logloss_remark(getattr(rep, "logloss", None))
        out["brier_score"] = Remarks.brier_remark(getattr(rep, "brier_score", None))

        out["ks_statistic"] = Remarks.ks_remark(getattr(rep, "ks_statistic", None))
        out["gini"] = Remarks.gini_remark(getattr(rep, "gini", None))

        out["confusion_matrix"] = Remarks.confusion_matrix_remark(getattr(rep, "confusion_matrix", None))
        out["calibration"] = Remarks.calibration_remark(getattr(rep, "calibration_curve", None))

        out["lift_gain"] = Remarks.lift_gain_remark(getattr(rep, "lift_gain_table", None))
        out["psi_score"] = Remarks.psi_remark(getattr(rep, "psi_score", None))

        # convert to plain dict
        return {k: {"status": v.status, "message": v.message, "value": v.value} for k, v in out.items()}




# rep = Metrics.classification_report(
#     y_true=y_true,
#     y_pred=y_pred,
#     y_proba=y_proba_pos,   # needed for KS/Gini/Brier/Calibration/Lift
#     compute_lift_gain=True
# )

# remarks = Remarks.classification_remarks(rep)
# print(remarks)

# # If you want only some remarks:
# wanted = {k: remarks[k] for k in ["auc", "ks_statistic", "lift_gain", "psi_score"]}
# print(wanted)