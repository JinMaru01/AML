# metrics_utils.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Union, List, Tuple

import math
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_curve,
    roc_auc_score,
    log_loss,
    precision_recall_curve,
    average_precision_score,
    matthews_corrcoef,
    cohen_kappa_score,
    top_k_accuracy_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    brier_score_loss,
)
from sklearn.calibration import calibration_curve


@dataclass
class ClassificationReport:
    # Core
    accuracy: float
    balanced_accuracy: float
    precision: Dict[str, float]          # micro/macro/weighted/(binary if possible)
    recall_sensitivity: Dict[str, float]
    f1: Dict[str, float]

    # Other
    mcc: float
    kappa: float
    logloss: Optional[float]

    # Confusion matrices
    labels: np.ndarray
    confusion_matrix: np.ndarray
    confusion_matrix_norm_true: np.ndarray
    confusion_matrix_norm_pred: np.ndarray
    confusion_matrix_norm_all: np.ndarray

    # Specificity
    specificity_binary: Optional[float]
    specificity_per_class: Dict[Any, float]

    # ROC / AUC
    auc_binary: Optional[float]
    roc_curve_binary: Optional[pd.DataFrame]
    auc_multiclass_ovr_weighted: Optional[float]
    auc_multiclass_ovo_weighted: Optional[float]

    # PR / AP
    ap_binary: Optional[float]
    pr_curve_binary: Optional[pd.DataFrame]
    ap_multiclass_ovr_weighted: Optional[float]

    # Binary probability extras
    ks_statistic: Optional[float]
    gini: Optional[float]
    brier_score: Optional[float]
    calibration_curve: Optional[pd.DataFrame]

    # Lift/Gain & Deciles (binary)
    lift_gain_table: Optional[pd.DataFrame]
    decile_table: Optional[pd.DataFrame]

    # PSI on score distribution (binary)
    psi_score: Optional[float]
    psi_score_table: Optional[pd.DataFrame]

    # Top-K (multiclass)
    topk: Dict[int, Optional[float]]


@dataclass
class RegressionReport:
    mae: float
    mse: float
    rmse: float
    r2: float
    mape: Optional[float]
    smape: Optional[float]


class Metrics:
    """
    Metrics from arrays only.
    Includes:
      - full classification metrics + tables
      - regression metrics
      - PSI/drift utilities (numeric + categorical)
      - selection of outputs
    """

    # -----------------------
    # Basic helpers
    # -----------------------

    @staticmethod
    def _to_numpy(y: Union[np.ndarray, pd.Series, list]) -> np.ndarray:
        if isinstance(y, pd.Series):
            return y.values
        return np.asarray(y)

    @staticmethod
    def _safe_div(num: float, den: float) -> float:
        return float(num / den) if den != 0 else 0.0

    @staticmethod
    def _ensure_labels(y_true: np.ndarray, labels: Optional[np.ndarray]) -> np.ndarray:
        return labels if labels is not None else np.unique(y_true)

    @staticmethod
    def _ensure_proba_shape(y_proba: np.ndarray, n_classes: int) -> np.ndarray:
        y_proba = np.asarray(y_proba)
        if n_classes == 2:
            if y_proba.ndim == 1:
                return y_proba
            if y_proba.ndim == 2 and y_proba.shape[1] == 2:
                return y_proba
            raise ValueError("Binary y_proba must be shape (n,) or (n,2).")
        else:
            if y_proba.ndim == 2 and y_proba.shape[1] == n_classes:
                return y_proba
            raise ValueError(f"Multiclass y_proba must be shape (n,{n_classes}).")

    @staticmethod
    def _pos_prob(y_proba: np.ndarray) -> np.ndarray:
        y_proba = np.asarray(y_proba)
        if y_proba.ndim == 1:
            return y_proba
        if y_proba.ndim == 2 and y_proba.shape[1] == 2:
            return y_proba[:, 1]
        raise ValueError("Binary y_proba must be shape (n,) or (n,2).")

    @staticmethod
    def threshold_binary(y_proba_pos: Union[np.ndarray, pd.Series, list], threshold: float = 0.5) -> np.ndarray:
        p = Metrics._to_numpy(y_proba_pos).astype(float)
        return (p >= threshold).astype(int)

    # -----------------------
    # Confusion-matrix derived
    # -----------------------

    @staticmethod
    def _specificity_binary(cm: np.ndarray) -> float:
        tn, fp, fn, tp = cm.ravel()
        return Metrics._safe_div(tn, tn + fp)

    @staticmethod
    def _specificity_per_class(cm: np.ndarray, labels: np.ndarray) -> Dict[Any, float]:
        specs: Dict[Any, float] = {}
        total = cm.sum()
        for i, lab in enumerate(labels):
            tp = cm[i, i]
            fp = cm[:, i].sum() - tp
            fn = cm[i, :].sum() - tp
            tn = total - tp - fp - fn
            specs[lab] = Metrics._safe_div(tn, tn + fp)
        return specs

    # -----------------------
    # Binary score extras
    # -----------------------

    @staticmethod
    def ks_statistic_binary(
        y_true: Union[np.ndarray, pd.Series, list],
        y_proba_pos: Union[np.ndarray, pd.Series, list],
        pos_label: Any = 1,
    ) -> float:
        """
        KS = max |CDF_pos(p) - CDF_neg(p)| across sorted probabilities.
        """
        yt = Metrics._to_numpy(y_true)
        p = Metrics._to_numpy(y_proba_pos).astype(float)

        order = np.argsort(p)
        yt_sorted = yt[order]

        pos = (yt_sorted == pos_label).astype(int)
        neg = 1 - pos

        pos_cum = np.cumsum(pos) / max(pos.sum(), 1)
        neg_cum = np.cumsum(neg) / max(neg.sum(), 1)

        return float(np.max(np.abs(pos_cum - neg_cum)))

    @staticmethod
    def gini_from_auc(auc: float) -> float:
        return float(2.0 * auc - 1.0)

    @staticmethod
    def brier_score_binary(
        y_true: Union[np.ndarray, pd.Series, list],
        y_proba_pos: Union[np.ndarray, pd.Series, list],
        pos_label: Any = 1,
    ) -> float:
        yt = Metrics._to_numpy(y_true)
        p = Metrics._to_numpy(y_proba_pos).astype(float)
        y01 = (yt == pos_label).astype(int)
        return float(brier_score_loss(y01, p))

    @staticmethod
    def calibration_curve_binary_df(
        y_true: Union[np.ndarray, pd.Series, list],
        y_proba_pos: Union[np.ndarray, pd.Series, list],
        *,
        pos_label: Any = 1,
        n_bins: int = 10,
        strategy: str = "uniform",  # 'uniform'|'quantile'
    ) -> pd.DataFrame:
        yt = Metrics._to_numpy(y_true)
        p = Metrics._to_numpy(y_proba_pos).astype(float)
        y01 = (yt == pos_label).astype(int)
        prob_true, prob_pred = calibration_curve(y01, p, n_bins=n_bins, strategy=strategy)
        return pd.DataFrame({"prob_pred": prob_pred, "prob_true": prob_true})

    # -----------------------
    # Lift / Gain / Deciles (binary)
    # -----------------------

    @staticmethod
    def lift_gain_table_binary(
        y_true: Union[np.ndarray, pd.Series, list],
        y_proba_pos: Union[np.ndarray, pd.Series, list],
        *,
        pos_label: Any = 1,
        n_bins: int = 10,
        strategy: str = "quantile",  # 'quantile'|'uniform'
    ) -> pd.DataFrame:
        """
        Returns a bin table sorted by score descending.
        Includes lift, gain, event rate, cumulative stats, KS-by-bin, overall KS.
        """
        yt = Metrics._to_numpy(y_true)
        p = Metrics._to_numpy(y_proba_pos).astype(float)
        y01 = (yt == pos_label).astype(int)

        df = pd.DataFrame({"y": y01, "p": p}).sort_values("p", ascending=False).reset_index(drop=True)

        # bin assignment
        if strategy == "quantile":
            # qcut on rank to avoid ties breaking qcut
            df["_rank"] = np.arange(len(df))
            df["bin"] = pd.qcut(df["_rank"], q=n_bins, labels=False, duplicates="drop") + 1
            df = df.drop(columns=["_rank"])
        elif strategy == "uniform":
            df["bin"] = pd.cut(np.arange(len(df)), bins=n_bins, labels=False, include_lowest=True) + 1
        else:
            raise ValueError("strategy must be 'quantile' or 'uniform'")

        total = len(df)
        total_pos = df["y"].sum()
        total_neg = total - total_pos

        g = df.groupby("bin", sort=True).agg(
            n=("y", "size"),
            positives=("y", "sum"),
            avg_score=("p", "mean"),
            min_score=("p", "min"),
            max_score=("p", "max"),
        ).reset_index()

        g["negatives"] = g["n"] - g["positives"]
        g["event_rate"] = g["positives"] / np.maximum(g["n"], 1)

        g["cum_n"] = g["n"].cumsum()
        g["cum_pos"] = g["positives"].cumsum()
        g["cum_neg"] = g["negatives"].cumsum()

        g["pop_pct_cum"] = g["cum_n"] / max(total, 1)
        g["pos_pct_cum"] = g["cum_pos"] / max(total_pos, 1)
        g["neg_pct_cum"] = g["cum_neg"] / max(total_neg, 1)

        # Gain = cumulative captured positive %
        g["gain"] = g["pos_pct_cum"]

        # Lift = gain / population %
        g["lift"] = g["gain"] / np.maximum(g["pop_pct_cum"], 1e-12)

        # KS per decile = |cum_pos_pct - cum_neg_pct|
        g["ks_by_bin"] = (g["pos_pct_cum"] - g["neg_pct_cum"]).abs()
        g["ks_overall"] = g["ks_by_bin"].max()

        # add top-decile indicator style stats
        g["bin"] = g["bin"].astype(int)

        # reorder columns nicely
        cols = [
            "bin", "n", "positives", "negatives",
            "event_rate", "avg_score", "min_score", "max_score",
            "cum_n", "cum_pos", "cum_neg",
            "pop_pct_cum", "pos_pct_cum", "neg_pct_cum",
            "gain", "lift", "ks_by_bin", "ks_overall",
        ]
        return g.loc[:, cols]

    @staticmethod
    def decile_table_binary(
        y_true: Union[np.ndarray, pd.Series, list],
        y_proba_pos: Union[np.ndarray, pd.Series, list],
        *,
        pos_label: Any = 1,
        n_bins: int = 10,
        strategy: str = "quantile",
    ) -> pd.DataFrame:
        # decile table is essentially lift/gain table with KS; provide alias for clarity
        return Metrics.lift_gain_table_binary(y_true, y_proba_pos, pos_label=pos_label, n_bins=n_bins, strategy=strategy)

    # -----------------------
    # PSI / Drift
    # -----------------------

    @staticmethod
    def _make_numeric_bins(
        expected: np.ndarray,
        bins: int,
        strategy: str,
    ) -> np.ndarray:
        """
        Returns bin edges including -inf and +inf.
        """
        x = expected.astype(float)
        x = x[np.isfinite(x)]
        if x.size == 0:
            # fallback single bin
            return np.array([-np.inf, np.inf], dtype=float)

        if strategy == "quantile":
            qs = np.linspace(0, 1, bins + 1)
            edges = np.unique(np.quantile(x, qs))
        elif strategy == "uniform":
            lo, hi = np.min(x), np.max(x)
            if lo == hi:
                edges = np.array([lo, hi])
            else:
                edges = np.linspace(lo, hi, bins + 1)
        else:
            raise ValueError("strategy must be 'quantile' or 'uniform'")

        # Ensure edges include extremes
        if edges.size < 2:
            edges = np.array([np.min(x), np.max(x)])
        edges[0] = -np.inf
        edges[-1] = np.inf
        return edges.astype(float)

    @staticmethod
    def psi_numeric(
        expected: Union[np.ndarray, pd.Series, list],
        actual: Union[np.ndarray, pd.Series, list],
        *,
        bins: int = 10,
        strategy: str = "quantile",  # 'quantile'|'uniform'
        eps: float = 1e-6,
    ) -> Tuple[float, pd.DataFrame]:
        """
        PSI for numeric distributions using bins derived from expected.
        """
        e = Metrics._to_numpy(expected).astype(float)
        a = Metrics._to_numpy(actual).astype(float)

        edges = Metrics._make_numeric_bins(e, bins=bins, strategy=strategy)

        e_counts, _ = np.histogram(e[np.isfinite(e)], bins=edges)
        a_counts, _ = np.histogram(a[np.isfinite(a)], bins=edges)

        e_pct = e_counts / max(e_counts.sum(), 1)
        a_pct = a_counts / max(a_counts.sum(), 1)

        # avoid zeros
        e_pct = np.clip(e_pct, eps, 1.0)
        a_pct = np.clip(a_pct, eps, 1.0)

        psi_bins = (a_pct - e_pct) * np.log(a_pct / e_pct)
        psi_total = float(np.sum(psi_bins))

        rows = []
        for i in range(len(e_counts)):
            rows.append({
                "bin": i + 1,
                "edge_left": edges[i],
                "edge_right": edges[i + 1],
                "expected_count": int(e_counts[i]),
                "actual_count": int(a_counts[i]),
                "expected_pct": float(e_pct[i]),
                "actual_pct": float(a_pct[i]),
                "psi_bin": float(psi_bins[i]),
            })
        table = pd.DataFrame(rows)
        table["psi_total"] = psi_total
        return psi_total, table

    @staticmethod
    def psi_categorical(
        expected: Union[np.ndarray, pd.Series, list],
        actual: Union[np.ndarray, pd.Series, list],
        *,
        eps: float = 1e-6,
        missing_bucket: str = "__MISSING__",
        other_bucket: Optional[str] = None,  # e.g. "__OTHER__"
        top_k: Optional[int] = None,         # keep top-k expected categories; rest -> other_bucket
    ) -> Tuple[float, pd.DataFrame]:
        """
        PSI for categorical distributions.
        """
        e = pd.Series(Metrics._to_numpy(expected), dtype="object").fillna(missing_bucket)
        a = pd.Series(Metrics._to_numpy(actual), dtype="object").fillna(missing_bucket)

        if top_k is not None and other_bucket is not None:
            top = e.value_counts().head(top_k).index
            e = e.where(e.isin(top), other=other_bucket)
            a = a.where(a.isin(top), other=other_bucket)

        e_counts = e.value_counts(dropna=False)
        a_counts = a.value_counts(dropna=False)
        cats = sorted(set(e_counts.index).union(set(a_counts.index)))

        e_total = int(e_counts.sum())
        a_total = int(a_counts.sum())

        rows = []
        psi_total = 0.0

        for c in cats:
            ec = int(e_counts.get(c, 0))
            ac = int(a_counts.get(c, 0))
            ep = max(ec / max(e_total, 1), eps)
            ap = max(ac / max(a_total, 1), eps)
            psi_bin = (ap - ep) * math.log(ap / ep)
            psi_total += psi_bin
            rows.append({
                "category": c,
                "expected_count": ec,
                "actual_count": ac,
                "expected_pct": float(ep),
                "actual_pct": float(ap),
                "psi_bin": float(psi_bin),
            })

        table = pd.DataFrame(rows).sort_values("psi_bin", ascending=False).reset_index(drop=True)
        table["psi_total"] = float(psi_total)
        return float(psi_total), table

    @staticmethod
    def psi_dataframe(
        expected_df: pd.DataFrame,
        actual_df: pd.DataFrame,
        *,
        columns: Optional[List[str]] = None,
        numeric_bins: int = 10,
        numeric_strategy: str = "quantile",
        categorical_top_k: Optional[int] = None,
        categorical_other_bucket: str = "__OTHER__",
        eps: float = 1e-6,
    ) -> Tuple[pd.DataFrame, Dict[str, pd.DataFrame]]:
        """
        Compute PSI for multiple columns.
        Returns:
          - summary_df: columns + psi + type
          - details: dict[col] -> psi table
        """
        cols = columns or sorted(set(expected_df.columns).intersection(set(actual_df.columns)))
        summary_rows = []
        details: Dict[str, pd.DataFrame] = {}

        for c in cols:
            e = expected_df[c]
            a = actual_df[c]

            # detect numeric
            is_num = pd.api.types.is_numeric_dtype(e) and pd.api.types.is_numeric_dtype(a)
            if is_num:
                psi, table = Metrics.psi_numeric(
                    expected=e.values,
                    actual=a.values,
                    bins=numeric_bins,
                    strategy=numeric_strategy,
                    eps=eps,
                )
                summary_rows.append({"feature": c, "psi": float(psi), "type": "numeric"})
                details[c] = table
            else:
                psi, table = Metrics.psi_categorical(
                    expected=e.values,
                    actual=a.values,
                    eps=eps,
                    other_bucket=categorical_other_bucket if categorical_top_k is not None else None,
                    top_k=categorical_top_k,
                )
                summary_rows.append({"feature": c, "psi": float(psi), "type": "categorical"})
                details[c] = table

        summary_df = pd.DataFrame(summary_rows).sort_values("psi", ascending=False).reset_index(drop=True)
        return summary_df, details

    # -----------------------
    # Classification report (FULL)
    # -----------------------

    @staticmethod
    def classification_report(
        y_true: Union[np.ndarray, pd.Series, list],
        y_pred: Union[np.ndarray, pd.Series, list],
        y_proba: Optional[np.ndarray] = None,
        *,
        labels: Optional[np.ndarray] = None,
        pos_label: Any = 1,
        averages: List[str] = ["micro", "macro", "weighted"],
        include_binary_scores_if_possible: bool = True,
        compute_roc_pr: bool = True,
        compute_logloss: bool = True,
        compute_extras_if_binary: bool = True,
        compute_lift_gain: bool = True,
        compute_psi_score: bool = True,
        topk_values: List[int] = [1, 2, 3, 5],
        calibration_bins: int = 10,
        calibration_strategy: str = "uniform",
        lift_bins: int = 10,
        lift_strategy: str = "quantile",
        psi_bins: int = 10,
        psi_strategy: str = "quantile",
        psi_eps: float = 1e-6,
    ) -> ClassificationReport:
        yt = Metrics._to_numpy(y_true)
        yp = Metrics._to_numpy(y_pred)
        labs = Metrics._ensure_labels(yt, labels)
        n_classes = len(labs)
        is_binary = (n_classes == 2)

        acc = float(accuracy_score(yt, yp))
        bal_acc = float(balanced_accuracy_score(yt, yp))

        prec: Dict[str, float] = {}
        rec: Dict[str, float] = {}
        f1d: Dict[str, float] = {}

        for avg in averages:
            prec[avg] = float(precision_score(yt, yp, average=avg, zero_division=0))
            rec[avg] = float(recall_score(yt, yp, average=avg, zero_division=0))
            f1d[avg] = float(f1_score(yt, yp, average=avg, zero_division=0))

        if include_binary_scores_if_possible and is_binary:
            prec["binary"] = float(precision_score(yt, yp, average="binary", pos_label=pos_label, zero_division=0))
            rec["binary"] = float(recall_score(yt, yp, average="binary", pos_label=pos_label, zero_division=0))
            f1d["binary"] = float(f1_score(yt, yp, average="binary", pos_label=pos_label, zero_division=0))

        cm = confusion_matrix(yt, yp, labels=labs)
        cm_norm_true = cm.astype(float) / np.maximum(cm.sum(axis=1, keepdims=True), 1.0)
        cm_norm_pred = cm.astype(float) / np.maximum(cm.sum(axis=0, keepdims=True), 1.0)
        cm_norm_all = cm.astype(float) / max(float(cm.sum()), 1.0)

        spec_bin = float(Metrics._specificity_binary(cm)) if (is_binary and cm.shape == (2, 2)) else None
        spec_per_class = Metrics._specificity_per_class(cm, labs)

        mcc = float(matthews_corrcoef(yt, yp))
        kappa = float(cohen_kappa_score(yt, yp))

        # proba-dependent
        auc_bin = None
        roc_df = None
        ap_bin = None
        pr_df = None
        auc_ovr_w = None
        auc_ovo_w = None
        ap_ovr_w = None
        ll = None
        topk_scores: Dict[int, Optional[float]] = {k: None for k in topk_values}

        ks = None
        gini = None
        brier = None
        calib_df = None

        lift_df = None
        decile_df = None

        psi_score = None
        psi_table = None

        if y_proba is not None:
            y_proba = Metrics._ensure_proba_shape(y_proba, n_classes=n_classes)

            if compute_logloss:
                try:
                    ll = float(log_loss(yt, y_proba, labels=labs))
                except Exception:
                    ll = None

            if is_binary:
                p_pos = Metrics._pos_prob(y_proba)

                if compute_roc_pr:
                    # ROC/AUC
                    try:
                        auc_bin = float(roc_auc_score(yt, p_pos))
                        fpr, tpr, thr = roc_curve(yt, p_pos, pos_label=pos_label)
                        roc_df = pd.DataFrame({"fpr": fpr, "tpr": tpr, "thresholds": thr})
                    except Exception:
                        auc_bin, roc_df = None, None

                    # PR/AP
                    try:
                        ap_bin = float(average_precision_score(yt, p_pos, pos_label=pos_label))
                        pr_prec, pr_rec, pr_thr = precision_recall_curve(yt, p_pos, pos_label=pos_label)
                        pr_df = pd.DataFrame({"precision": pr_prec, "recall": pr_rec})
                        pr_df["thresholds"] = np.nan
                        if len(pr_thr) > 0:
                            pr_df.loc[: len(pr_thr) - 1, "thresholds"] = pr_thr
                    except Exception:
                        ap_bin, pr_df = None, None

                if compute_extras_if_binary:
                    try:
                        ks = float(Metrics.ks_statistic_binary(yt, p_pos, pos_label=pos_label))
                    except Exception:
                        ks = None
                    if auc_bin is not None:
                        gini = float(Metrics.gini_from_auc(auc_bin))
                    try:
                        brier = float(Metrics.brier_score_binary(yt, p_pos, pos_label=pos_label))
                    except Exception:
                        brier = None
                    try:
                        calib_df = Metrics.calibration_curve_binary_df(
                            yt, p_pos, pos_label=pos_label, n_bins=calibration_bins, strategy=calibration_strategy
                        )
                    except Exception:
                        calib_df = None

                if compute_lift_gain:
                    try:
                        lift_df = Metrics.lift_gain_table_binary(
                            yt, p_pos, pos_label=pos_label, n_bins=lift_bins, strategy=lift_strategy
                        )
                        # decile alias (same table)
                        decile_df = lift_df.copy()
                    except Exception:
                        lift_df, decile_df = None, None

                if compute_psi_score:
                    try:
                        psi_score, psi_table = Metrics.psi_numeric(
                            expected=p_pos,  # for a single batch you can store "expected" from baseline later
                            actual=p_pos,
                            bins=psi_bins,
                            strategy=psi_strategy,
                            eps=psi_eps,
                        )
                        # NOTE: This is a placeholder if you pass same array. In production,
                        # call Metrics.psi_numeric(expected=baseline_scores, actual=current_scores).
                    except Exception:
                        psi_score, psi_table = None, None

            else:
                if compute_roc_pr:
                    try:
                        auc_ovr_w = float(roc_auc_score(yt, y_proba, multi_class="ovr", average="weighted"))
                    except Exception:
                        auc_ovr_w = None
                    try:
                        auc_ovo_w = float(roc_auc_score(yt, y_proba, multi_class="ovo", average="weighted"))
                    except Exception:
                        auc_ovo_w = None
                    try:
                        ap_ovr_w = float(average_precision_score(yt, y_proba, average="weighted"))
                    except Exception:
                        ap_ovr_w = None

                # top-k
                for k in topk_values:
                    try:
                        topk_scores[k] = float(top_k_accuracy_score(yt, y_proba, k=k, labels=labs))
                    except Exception:
                        topk_scores[k] = None

        return ClassificationReport(
            accuracy=acc,
            balanced_accuracy=bal_acc,
            precision=prec,
            recall_sensitivity=rec,
            f1=f1d,
            mcc=mcc,
            kappa=kappa,
            logloss=ll,
            labels=labs,
            confusion_matrix=cm,
            confusion_matrix_norm_true=cm_norm_true,
            confusion_matrix_norm_pred=cm_norm_pred,
            confusion_matrix_norm_all=cm_norm_all,
            specificity_binary=spec_bin,
            specificity_per_class=spec_per_class,
            auc_binary=auc_bin,
            roc_curve_binary=roc_df,
            auc_multiclass_ovr_weighted=auc_ovr_w,
            auc_multiclass_ovo_weighted=auc_ovo_w,
            ap_binary=ap_bin,
            pr_curve_binary=pr_df,
            ap_multiclass_ovr_weighted=ap_ovr_w,
            ks_statistic=ks,
            gini=gini,
            brier_score=brier,
            calibration_curve=calib_df,
            lift_gain_table=lift_df,
            decile_table=decile_df,
            psi_score=psi_score,
            psi_score_table=psi_table,
            topk=topk_scores,
        )

    # -----------------------
    # Regression report
    # -----------------------

    @staticmethod
    def regression_report(
        y_true: Union[np.ndarray, pd.Series, list],
        y_pred: Union[np.ndarray, pd.Series, list],
        *,
        mape_eps: float = 1e-9,
    ) -> RegressionReport:
        yt = Metrics._to_numpy(y_true).astype(float)
        yp = Metrics._to_numpy(y_pred).astype(float)

        mae = float(mean_absolute_error(yt, yp))
        mse = float(mean_squared_error(yt, yp))
        rmse = float(math.sqrt(mse))
        r2 = float(r2_score(yt, yp))

        denom = np.maximum(np.abs(yt), mape_eps)
        mape = float(np.mean(np.abs((yt - yp) / denom)) * 100.0) if len(yt) else None

        smape_denom = np.maximum((np.abs(yt) + np.abs(yp)) / 2.0, mape_eps)
        smape = float(np.mean(np.abs(yt - yp) / smape_denom) * 100.0) if len(yt) else None

        return RegressionReport(mae=mae, mse=mse, rmse=rmse, r2=r2, mape=mape, smape=smape)

    # -----------------------
    # Select only what you want
    # -----------------------

    @staticmethod
    def select_from_classification_report(rep: ClassificationReport, keys: List[str]) -> Dict[str, Any]:
        """
        keys examples:
          - "accuracy"
          - "precision.micro"
          - "recall_sensitivity.macro"
          - "f1.weighted"
          - "confusion_matrix"
          - "confusion_matrix_norm_true"
          - "specificity_binary"
          - "specificity_per_class"
          - "auc_binary"
          - "roc_curve_binary"
          - "ap_binary"
          - "pr_curve_binary"
          - "ks_statistic"
          - "gini"
          - "brier_score"
          - "calibration_curve"
          - "lift_gain_table"
          - "decile_table"
          - "psi_score"
          - "psi_score_table"
          - "topk.3"
        """
        out: Dict[str, Any] = {}

        for k in keys:
            if "." in k:
                base, sub = k.split(".", 1)
                if base == "precision":
                    out[k] = rep.precision.get(sub)
                elif base == "recall_sensitivity":
                    out[k] = rep.recall_sensitivity.get(sub)
                elif base == "f1":
                    out[k] = rep.f1.get(sub)
                elif base == "topk":
                    try:
                        kk = int(sub)
                        out[k] = rep.topk.get(kk)
                    except Exception:
                        out[k] = None
                else:
                    out[k] = None
                continue

            # direct fields
            if hasattr(rep, k):
                out[k] = getattr(rep, k)
            else:
                out[k] = None

        return out

    @staticmethod
    def select_from_regression_report(rep: RegressionReport, keys: List[str]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for k in keys:
            out[k] = getattr(rep, k, None)
        return out



# rep = Metrics.classification_report(
#     y_true=y_true,
#     y_pred=y_pred,
#     y_proba=y_proba_pos,   # (n,) or (n,2)
#     compute_lift_gain=True,
#     compute_psi_score=False,  # usually you compute PSI vs baseline separately (see below)
# )

# # Get only what you want:
# selected = Metrics.select_from_classification_report(rep, keys=[
#     "accuracy",
#     "precision.micro",
#     "recall_sensitivity.macro",
#     "f1.weighted",
#     "confusion_matrix",
#     "roc_curve_binary",
#     "auc_binary",
#     "lift_gain_table",
#     "decile_table",
#     "ks_statistic",
#     "gini",
#     "brier_score",
#     "calibration_curve",
# ])






# # baseline_scores: stored from training or last good week
# # current_scores: scores from today batch

# psi_total, psi_table = Metrics.psi_numeric(
#     expected=baseline_scores,
#     actual=current_scores,
#     bins=10,
#     strategy="quantile"
# )
# print(psi_total)
# print(psi_table)



# summary_df, details = Metrics.psi_dataframe(
#     expected_df=train_df,
#     actual_df=prod_df,
#     columns=None,               # or provide list
#     numeric_bins=10,
#     numeric_strategy="quantile",
#     categorical_top_k=50,
# )

# print(summary_df.head())
# print(details["some_feature"].head())
