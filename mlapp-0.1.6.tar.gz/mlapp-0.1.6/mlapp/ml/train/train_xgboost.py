"""
Import XGBoost class & relevant libraries

When it's ready to train:
    - run this command: `python -m mlapp.ml.train.<file-name-without-extension>`
"""
import pandas as pd
from ..classification import XGBoost


if __name__ == '__main__':
    # =========================
    # Initiate model and tuning parameters
    # =========================
    xgb_model = XGBoost()
    xgb_model.set_tuning_params()

    # =========================
    # Load data from GitHub or any sources
    # =========================
    url = "https://raw.githubusercontent.com/shrikant-temburwar/Wine-Quality-Dataset/master/winequality-red.csv"
    data = pd.read_csv(url, sep=";")

    # =========================
    # Target engineering
    # =========================
    data["quality_label"] = (data["quality"] >= 6).astype(int)

    X = data.drop(columns=["quality", "quality_label"])
    y = data["quality_label"].values

    # =========================
    # Data preprocessing & Feature Selection (Optional)
    # =========================
    xgb_model.data_pipeline \
        .power_transform(
            cols=["residual sugar", "free sulfur dioxide", "total sulfur dioxide", "chlorides"], 
            method="yeo-johnson", 
            standardize=True
        ) \
        .scale(kind="standard")
    
    # =========================
    # Model training
    # =========================
    X_test, y_test = xgb_model.fit(X=X, y=y)
    y_pred = xgb_model.predict(X_test)

    # =========================
    # Model evaluation
    # =========================
    y_pred = xgb_model.predict(X_test)
    y_proba = xgb_model.predict_proba(X_test)

    # =========================
    # Metrics
    # =========================
    xgb_model.build_metrics(y_test=y_test, y_pred=y_pred, keys=["accuracy"])
    print(xgb_model.metrics)
    print(xgb_model.best_params_)

    # =========================
    # Model Info
    # =========================
    print(xgb_model.info)
