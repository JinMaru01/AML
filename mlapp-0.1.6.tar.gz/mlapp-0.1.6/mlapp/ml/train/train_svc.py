"""
Import SVC class & relevant libraries

When it's ready to train:
    - run this command: `python -m mlapp.ml.train.<file-name-without-extension>`
"""
import pandas as pd
from ..classification import SVC


if __name__ == '__main__':
    # =========================
    # Initiate model and tuning parameters
    # =========================
    model = SVC(kernel='rbf')
    model.set_tuning_params()

    # =========================
    # Load data from GitHub or any sources
    # =========================
    csv_path = "backend/mlapp_repo/mlapp/ml/data/synthetic_bank_churn.csv"
    df = pd.read_csv(csv_path)

    # =========================
    # Target engineering
    # =========================
    X = df.drop(columns=["churn_flag"])
    y = df["churn_flag"]

    # =========================
    # Data preprocessing & Feature Selection (Optional)
    # =========================
    model.data_pipeline \
        .impute(numeric_strategy="mean") \
        .scale(kind="standard") 

    # =========================
    # Model training
    # =========================
    X_test, y_test = model.fit(X, y, search_method=None, tuning_params=model.tuning_params)
    print(model.best_params_)

    # =========================
    # Model evaluation
    # =========================
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)

    # =========================
    # Metrics
    # =========================
    model.build_metrics(y_test=y_test, y_pred=y_pred, y_pred_proba=y_proba, keys=['accuracy'])
    print(model.metrics)

    # =========================
    # Model Info
    # =========================
    print(model.info)
