import sys
sys.path.append("D:/Work/ade/ade/backend")
from mlapp_repo.mlapp.ml.classification.base import BaseModel
from sklearn.linear_model import LogisticRegression
import pandas as pd 
import sklearn as sns
import numpy as np 
from typing import Optional, Dict, Any
import warnings
from config_path import DATA

warnings.filterwarnings("ignore")

class Logistic_Regression(BaseModel):
    """
    Logistic Regression classifier 
    It supports hyperparameter tuning using the `set_tuning_params()` method.

    Parameters
    ----------

    penalty : {'l1', 'l2', 'elasticnet', None}, default='l2'
        Norm used in the penalization.
    dual : bool, default=False
        Dual or primal formulation.
    tol : float, default=1e-4
        Tolerance for stopping criteria.
    C : float, default=1.0
        Inverse of regularization strength.
    fit_intercept : bool, default=True
        Specifies if a constant (bias) should be added to the decision function.
    intercept_scaling : float, default=1.0
        Scaling of the intercept term when using the 'liblinear' solver.
    class_weight : dict, 'balanced', or None, default=None
        Weights associated with classes.
    random_state : int, RandomState instance, or None, default=None
        Seed for random number generation.
    solver : {'lbfgs', 'liblinear', 'newton-cg', 'newton-cholesky', 'sag', 'saga'}, default='lbfgs'
        Algorithm to use in the optimization problem.
    max_iter : int, default=100
        Maximum number of iterations taken for the solvers to converge.
    multi_class : {'auto', 'ovr', 'multinomial'}, default='auto'
        Multiclass option.
    verbose : int, default=0
        Verbosity level.
    warm_start : bool, default=False
        Reuse the solution of the previous call to fit.
    n_jobs : int or None, default=None
        Number of CPU cores used when parallelizing over classes.
    l1_ratio : float or None, default=None
        Elastic-Net mixing parameter (only used if penalty='elasticnet').

    """

    def __init__(
        self,
        penalty: str = "l2",
        *,
        C: float = 1.0,
        l1_ratio: Optional[float] = None,
        dual: bool = False,
        tol: float = 1e-4,
        fit_intercept: bool = True,
        intercept_scaling: float = 1.0,
        class_weight=None,
        random_state=None,
        solver: str = "lbfgs",
        max_iter: int = 100,
        verbose: int = 0,
        warm_start: bool = False,
        n_jobs: Optional[int] = None,
    ):
        model = LogisticRegression(
            penalty=penalty,
            C=C,
            l1_ratio=l1_ratio,
            dual=dual,
            tol=tol,
            fit_intercept=fit_intercept,
            intercept_scaling=intercept_scaling,
            class_weight=class_weight,
            random_state=random_state,
            solver=solver,
            max_iter=max_iter,
            verbose=verbose,
            warm_start=warm_start,
            n_jobs=n_jobs,
        )
        super().__init__(model=model, model_name="LogisticRegression_Wing")
        self.tuning_params = {
            "C": [0.01, 0.1, 1, 10],
            "solver": ["liblinear"],
            "max_iter": [500, 1000]
        }
    
    def set_tuning_params(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Set or update the hyperparameter grid for tuning.

        Parameters
        ----------
        params : dict or None, default=None
            A dictionary of hyperparameters to try during tuning.
            If None, the current tuning grid will be returned.

            Example:
                {
                    "C": [0.01, 0.1, 1, 10],
                    "solver": ["liblinear", "lbfgs"]
                }

        Returns
        -------
        dict
            The updated tuning grid.

        Examples
        --------
        >>> model = Logistic_Regression()
        >>> model.set_tuning_params({
        ...     "C": [0.01, 0.1, 1, 10],
        ...     "solver": ["liblinear", "lbfgs"]
        ... })
        """

        if params is None:
            return self.tuning_params

        self.tuning_params.update(params)
        return self.tuning_params

    
if __name__ == '__main__':
    model = Logistic_Regression()
    path = DATA/ "archive 2" / "train_ctrUa4K.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    data = pd.read_csv(path)

    data["Loan_Status"].value_counts(normalize = True).reset_index()
    data['Dependents'].replace('3+', 3, inplace=True)
    data['Loan_Status'].replace({'N': 0, 'Y': 1}, inplace=True)
    y = data['Loan_Status']
    X = data.drop(columns=['Loan_ID', 'Loan_Status'])
    model = Logistic_Regression()
    # ---- FEATURE PIPELINE (IMPORTANT FOR LOGISTIC REGRESSION) ----

    model.data_pipeline.schema(enforce=True)\
    .infer_columns()\
    .impute(
        numeric_strategy="median",
        categorical_strategy="most_frequent",
        add_missing_indicators=True
    )\
    .encode_onehot()\
    .build()
    params = {
        "penalty": ['l1', 'l2', 'elasticnet'],
        "C": np.logspace(-4, 4, 20),
        "solver": ['lbfgs']}
    model.set_tuning_params(params)
    # ---- TRAIN ----
    X_train, X_test, y_train, y_test = model.fit(X, y, test_size =0.3 ,search_method = 'grid')
    # ---- PREDICT ----
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)  
    # ---- METRICS ----
    metrics = model.build_metrics(
        y_test=y_test,
        y_pred=y_pred,
        y_pred_proba=y_pred_proba
    )
    print("\n===== METRICS =====")
    print(metrics.accuracy)

    model = Logistic_Regression()

    model.set_tuning_params()
