# Initialize model
# import sys
# sys.path.append("backend/mlapp_repo")
from typing import Optional
import pandas as pd

from mlapp.ml.classification.base import BaseModel 
from xgboost import XGBClassifier


class XGBoost(BaseModel):
    """
    Comprehensive XGBoost wrapper with optional hyperparameter tuning (Grid, Random, Bayesian),
    cross-validation, and prediction functionality.

    Parameters
    ----------
    max_depth : int, default=6
        Maximum depth of a tree.
    learning_rate : float, default=0.3
        Boosting learning rate.
    n_estimators : int, default=100
        Number of boosting rounds.
    objective : str, default="binary:logistic"
        Learning objective.
    n_jobs : int, optional
        Number of parallel threads used to run XGBoost.
    gamma : float, default=0
        Minimum loss reduction required to make a further partition on a leaf node.
    min_child_weight : float, default=1
        Minimum sum of instance weight (hessian) needed in a child.
    max_delta_step : float, default=0
        Maximum delta step we allow each tree’s weight estimation to be.
    subsample : float, default=1.0
        Subsample ratio of the training instances.
    sampling_method : str, optional
        The sampling method for subsample.
    reg_alpha : float, default=0
        L1 regularization term on weights.
    reg_lambda : float, default=1
        L2 regularization term on weights.
    scale_pos_weight : float, default=1
        Balancing of positive and negative weights.
    """
    def __init__(
        self,
        *,
        max_depth: int = 6,
        learning_rate: float = 0.3,
        n_estimators: int = 100,
        objective: str = "binary:logistic",
        n_jobs: Optional[int] = None,
        gamma: float = 0,
        min_child_weight: float = 1,
        max_delta_step: float = 0,
        subsample: float = 1.0,
        sampling_method: Optional[str] = None,
        reg_alpha: float = 0,
        reg_lambda: float = 1,
        scale_pos_weight: float = 1,
    ):
        model = XGBClassifier(
            max_depth=max_depth,
            learning_rate=learning_rate,
            n_estimators=n_estimators,
            objective=objective,
            n_jobs=n_jobs,
            gamma=gamma,
            min_child_weight=min_child_weight,
            max_delta_step=max_delta_step,
            subsample=subsample,
            sampling_method=sampling_method,
            reg_alpha=reg_alpha,
            reg_lambda=reg_lambda,
            scale_pos_weight=scale_pos_weight,
        )
        model_name = "Wing XGBoost"
        super().__init__(model=model, model_name=model_name)

        # default params for hyperparams tuning process
        self.tuning_params = {
            "n_estimators": [100, 300, 500],       # number of trees
            "max_depth": [3, 5, 7, 10],            # tree depth (model complexity)
            "learning_rate": [0.01, 0.05, 0.1],    # shrinkage
            "subsample": [0.7, 0.85, 1.0],         # row sampling
            "colsample_bytree": [0.7, 0.85, 1.0],  # feature sampling
            "gamma": [0, 0.1, 0.3],                # min loss reduction to split
            "min_child_weight": [1, 3, 5],         # min samples per leaf
            "reg_alpha": [0, 0.1, 1],              # L1 regularization
            "reg_lambda": [1, 5, 10]               # L2 regularization
        }
    
    def set_tuning_params(
        self,
        n_estimators: list[int] | None = None,
        max_depth: list[int] | None = None,
        learning_rate: list[float] | None = None,
        subsample: list[float] | None = None,
        colsample_bytree: list[float] | None = None,
        gamma: list[float] | None = None,
        min_child_weight: list[int] | None = None,
        reg_alpha: list[float] | None = None,
        reg_lambda: list[float] | None = None
    ) -> None:
        """
        Update the hyperparameter grid for model tuning for XGBoost.

        Parameters
        ----------
        n_estimators : list of int, optional
            Number of boosting trees (default: [100, 300, 500]).
        max_depth : list of int, optional
            Maximum tree depth (default: [3, 5, 7, 10]).
        learning_rate : list of float, optional
            Step size shrinkage (default: [0.01, 0.05, 0.1]).
        subsample : list of float, optional
            Fraction of samples used per tree (default: [0.7, 0.85, 1.0]).
        colsample_bytree : list of float, optional
            Fraction of features used per tree (default: [0.7, 0.85, 1.0]).
        gamma : list of float, optional
            Minimum loss reduction to make a split (default: [0, 0.1, 0.3]).
        min_child_weight : list of int, optional
            Minimum sum of instance weights per leaf (default: [1, 3, 5]).
        reg_alpha : list of float, optional
            L1 regularization term (default: [0, 0.1, 1]).
        reg_lambda : list of float, optional
            L2 regularization term (default: [1, 5, 10]).
        """

        if n_estimators is not None:
            self.tuning_params["n_estimators"] = n_estimators
        if max_depth is not None:
            self.tuning_params["max_depth"] = max_depth
        if learning_rate is not None:
            self.tuning_params["learning_rate"] = learning_rate
        if subsample is not None:
            self.tuning_params["subsample"] = subsample
        if colsample_bytree is not None:
            self.tuning_params["colsample_bytree"] = colsample_bytree
        if gamma is not None:
            self.tuning_params["gamma"] = gamma
        if min_child_weight is not None:
            self.tuning_params["min_child_weight"] = min_child_weight
        if reg_alpha is not None:
            self.tuning_params["reg_alpha"] = reg_alpha
        if reg_lambda is not None:
            self.tuning_params["reg_lambda"] = reg_lambda
