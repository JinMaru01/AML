from lightgbm import LGBMClassifier
from mlapp.ml.classification.base import BaseModel


class LightGBM(BaseModel):

    def __init__(self):
        model = LGBMClassifier(
            objective="binary",
            boosting_type="gbdt",
            random_state=42,
            n_jobs=-1
        )

        super().__init__(
            model=model,
            model_name="LightGBM Classifier"
        )

        self.tuning_params = {
            "num_leaves": [16, 32, 64],
            "max_depth": [4, 6, 8],
            "learning_rate": [0.01, 0.03, 0.05],
            "n_estimators": [500, 1000, 2000],

            "min_child_samples": [100, 200, 500],
            "min_split_gain": [0.01, 0.05, 0.1],

            "feature_fraction": [0.6, 0.8],
            "bagging_fraction": [0.6, 0.8],
            "bagging_freq": [5],

            "reg_alpha": [0.5, 1.0, 2.0],
            "reg_lambda": [1.0, 2.0, 5.0],

            "scale_pos_weight": [100, 300, 500]
        }

    def set_tuning_params(
        self,
        num_leaves: list[int] | None = None,
        max_depth: list[int] | None = None,
        learning_rate: list[float] | None = None,
        n_estimators: list[int] | None = None,
        min_child_samples: list[int] | None = None,
        min_split_gain: list[float] | None = None,
        feature_fraction: list[float] | None = None,
        bagging_fraction: list[float] | None = None,
        bagging_freq: list[int] | None = None,
        reg_alpha: list[float] | None = None,
        reg_lambda: list[float] | None = None,
        scale_pos_weight: list[int] | None = None
    ) -> None:
        """
        Update the hyperparameter grid for LightGBM tuning.

        Parameters
        ----------
        num_leaves : list of int, optional
            Maximum number of leaves per tree.

        max_depth : list of int, optional
            Maximum tree depth (-1 means no limit).

        learning_rate : list of float, optional
            Boosting learning rate.

        n_estimators : list of int, optional
            Number of boosting iterations.

        min_child_samples : list of int, optional
            Minimum data in one leaf (important for AML stability).

        min_split_gain : list of float, optional
            Minimum loss reduction required to make a split.

        feature_fraction : list of float, optional
            Fraction of features used per iteration.

        bagging_fraction : list of float, optional
            Fraction of data used per iteration.

        bagging_freq : list of int, optional
            Bagging frequency.

        reg_alpha : list of float, optional
            L1 regularization.

        reg_lambda : list of float, optional
            L2 regularization.

        scale_pos_weight : list of int, optional
            Class imbalance control (AML critical).
        """

        if num_leaves is not None:
            self.tuning_params["num_leaves"] = num_leaves
        if max_depth is not None:
            self.tuning_params["max_depth"] = max_depth
        if learning_rate is not None:
            self.tuning_params["learning_rate"] = learning_rate
        if n_estimators is not None:
            self.tuning_params["n_estimators"] = n_estimators
        if min_child_samples is not None:
            self.tuning_params["min_child_samples"] = min_child_samples
        if min_split_gain is not None:
            self.tuning_params["min_split_gain"] = min_split_gain
        if feature_fraction is not None:
            self.tuning_params["feature_fraction"] = feature_fraction
        if bagging_fraction is not None:
            self.tuning_params["bagging_fraction"] = bagging_fraction
        if bagging_freq is not None:
            self.tuning_params["bagging_freq"] = bagging_freq
        if reg_alpha is not None:
            self.tuning_params["reg_alpha"] = reg_alpha
        if reg_lambda is not None:
            self.tuning_params["reg_lambda"] = reg_lambda
        if scale_pos_weight is not None:
            self.tuning_params["scale_pos_weight"] = scale_pos_weight
