from mlapp.ml.classification.base import BaseModel
from sklearn.neighbors import KNeighborsClassifier
from typing import Optional, Dict, Any
from mlapp.ml.classification.base import BaseModel
import pandas as pd 
from config_path import DATA
import warnings

warnings.filterwarnings("ignore")

class KNN(BaseModel):
    """
    K-Nearest Neighbors (KNN) classifier.

    It supports hyperparameter tuning using the `set_tuning_params()` method.

    Parameters
    ----------
    n_neighbors : int, default=5
        Number of neighbors to use for k-neighbors queries.
    weights : {'uniform', 'distance'} or callable, default='uniform'
        Weight function used in prediction.
    algorithm : {'auto', 'ball_tree', 'kd_tree', 'brute'}, default='auto'
        Algorithm used to compute the nearest neighbors.
    leaf_size : int, default=30
        Leaf size passed to BallTree or KDTree.
    p : int, default=2
        Power parameter for the Minkowski metric.
    metric : str or callable, default='minkowski'
        Distance metric to use for the tree.
    metric_params : dict or None, default=None
        Additional keyword arguments for the metric function.
    n_jobs : int or None, default=None
        Number of parallel jobs to run for neighbors search.

    Methods
    -------

    set_tuning_params(params)
        Update the hyperparameter grid used for tuning.

    """
    def __init__(
        self,
        n_neighbors: int = 5,
        *,
        weights: str = "uniform",
        algorithm: str = "auto",
        leaf_size: int = 30,
        p: int = 2,
        metric: str = "minkowski",
        metric_params: Optional[dict] = None,
        n_jobs: Optional[int] = None,
    ):
        model = KNeighborsClassifier(
            n_neighbors=n_neighbors,
            weights=weights,
            algorithm=algorithm,
            leaf_size=leaf_size,
            p=p,
            metric=metric,
            metric_params=metric_params,
            n_jobs=n_jobs,
        )
        super().__init__(model=model, model_name="K-Nearest Neighbors (KNN)")

        self.tuning_params = {
            "n_neighbors": [3, 5, 7, 9, 11, 15, 21],
            "weights": ["uniform", "distance"],
            "metric": ["euclidean", "manhattan", "minkowski"],
            "p": [1, 2],
        }


    def set_tuning_params(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Set or update the hyperparameter grid used for tuning.

        Parameters
        ----------
        params : dict or None, default=None
            Dictionary specifying hyperparameters and their candidate
            values for tuning. If None, the current tuning parameter
            grid is returned.

            Common tuning parameters include:
                - n_neighbors : int
                - weights : {'uniform', 'distance'}
                - metric : str
                - p : int

        Returns
        -------
        dict
            Updated hyperparameter grid used for tuning.

        Examples
        --------
        >>> knn = KNN()
        >>> knn.set_tuning_params({
        ...     "n_neighbors": [5, 7, 9],
        ...     "weights": ["distance"]
        ... })
        """

        if params is None:
            return self.tuning_params

        self.tuning_params.update(params)
        return self.tuning_params

if __name__ == '__main__':


    # ----------------------------
    # Step 1: Load dataset
    # ----------------------------
    path = DATA / "german.data"
    path.parent.mkdir(parents=True, exist_ok=True)
    # print(path)

    df = pd.read_csv(path, sep=" ", header=None)
    # print(df.head())

    # ----------------------------
    # Step 2: Save as CSV
    # ----------------------------
    csv_path = DATA  / "german.csv"
    df.to_csv(csv_path, index=False)
    # print("Saved CSV at:", csv_path)

    # ----------------------------
    # Step 3: Add column names
    # ----------------------------
    columns = [
        "checking_status", "duration", "credit_history", "purpose", "credit_amount",
        "savings", "employment", "installment_rate", "personal_status", "other_debtors",
        "residence_since", "property", "age", "other_installment_plans",
        "housing", "num_credits", "job", "num_dependents", "telephone",
        "foreign_worker", "risk"
    ]

    df.columns = columns
    # print(df)


    # Split X and y
    X = df.drop("risk", axis=1)
    y = df["risk"]

    # ---- INIT MODEL ----
    knn = KNN(n_neighbors=9, weights='distance', metric='manhattan')
    knn.set_tuning_params()


    # ---- FEATURE PIPELINE (IMPORTANT FOR KNN) ----
    knn.data_pipeline.impute()\
        .scale()\
        .build()
    

    # ---- TRAIN ----
    X_train, X_test, y_train, y_test  = knn.fit(X, y,test_size = 0.3 ,search_method='grid' ,stratify = True )  

    # ---- PREDICT ----
    y_pred = knn.predict(X_test)
    y_pred_proba = knn.predict_proba(X_test)

    # ---- METRICS ----
    metrics = knn.build_metrics(
        y_test=y_test,
        y_pred=y_pred,
        y_pred_proba=y_pred_proba
    )

    print("\n===== METRICS =====")
    print(metrics.accuracy)

    


