import sys
import numpy as np
import pandas as pd

class LogisticRegression:
    
    def __init__(self, model, iv, bin):        
        self.iv = iv
        self.bin = bin
        self.model = model
        self.modelname = "Wing Logistic Regression"
        self.python_version = f"{sys.version.split()[0]}"

    def input_schema(self):
        schema = {}
        param_list = self.model.params.index.to_list()
        filtered_list = [item.removeprefix("WOE_") for item in param_list if item.startswith("WOE_")]
        for item in filtered_list:
            dtype = self.iv[item]['woe'].dtype
            schema[item] = dtype
        return schema
    
    def info(self):
        modelinfo=[]
        model_stats = {
            "AIC": self.model.aic,
            "BIC": self.model.bic_llf,
            "Log-Likelihood": self.model.llf,
            "LL-Null": self.model.llnull,
            "Deviance": self.model.deviance,
            "Pearson chi2": self.model.pearson_chi2,
            "Scale": self.model.scale,
            "DF Model": self.model.df_model,
            "DF Residuals": self.model.df_resid,
            "Number of Observations": self.model.nobs
        }
        modelinfo.append({"groupname":"Basic information", "info": model_stats })
        modelinfo.append({"groupname":"Summary", "info": self.summary() })
        return modelinfo
    
    def summary(self):
        variables = self.model.params.index
        data = []

        for var in variables:
            data.append({
                'Variable': var,
                'Coef.': round(self.model.params[var], 2),
                'Std.Err.': round(self.model.bse[var], 2),
                'z': round(self.model.tvalues[var], 2),
                'P>|z|': round(self.model.pvalues[var], 2),
                '0.025': round(self.model.conf_int().loc[var, 0], 2),
                '0.975': round(self.model.conf_int().loc[var, 1], 2)
            })
        return data
    
    def predict(self, data):
        if isinstance(data, dict):
            df = pd.DataFrame([data])
        elif isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, pd.DataFrame):
            df = data.copy()
        else:
            raise ValueError(f"Unsupported input type: {type(data)}")
        self.woe_transform(df, self.iv, 0.03)
        df_score_woe= df.loc[:, df.columns.str.startswith('WOE')]
        # df_score_woe.info()
        predict_score = self.model.predict(exog = df_score_woe)
        pscore = predict_score.loc[0]
        factor = 20/np.log(2)
        offset = (700 + 1 * (factor * np.log(12/95)))
        Min = pscore/(1-pscore)
        odds_ratio_min = Min/(1-Min)

        # Predict Result:
        predict_score = predict_score.to_frame()
        predict_score = predict_score.rename(columns={0:'Prob'})

        predict_score['Min_Max'] = pd.cut(predict_score['Prob'], self.bin, duplicates='drop')
        predict_score['Min'] = predict_score['Min_Max'].apply(lambda x: x.left).astype('float')
        predict_score['Max'] = predict_score['Min_Max'].apply(lambda x: x.right).astype('float')
        predict_score['Percentile'] = pd.cut(predict_score['Prob'], self.bin, duplicates='drop',
                                            labels=['1','2','3','4','5','6','7','8','9','10'])
        predict_score = self.score_card(predict_score)
        result_dict = predict_score.to_dict(orient="records")[0]
        return result_dict
   
    def score_card(self, predict_score):
        score_card = predict_score[predict_score['Min_Max'].notnull()]
        #score_card = predict_score_1.reset_index()
        score_card['factor'] = round(20/np.log(2),2)
        score_card['offset'] = round((700 + 1 * (score_card['factor'] * np.log(12/95))),2)
        score_card['odds_ratio_min'] = round(score_card['Min']/(1-score_card['Min']),6)
        score_card['odds_ratio_max'] = round(score_card['Max']/(1-score_card['Max']),6)
        score_card['final_score_min'] = round(score_card['offset'] + (-1 * (score_card['factor'] * np.log(score_card['odds_ratio_min'])))).astype('int')
        score_card['final_score_max'] = round(score_card['offset'] + (-1 * (score_card['factor'] * np.log(score_card['odds_ratio_max'])))).astype('int')
        score_card["Min_Max_Score"]= score_card['final_score_max'].astype(str) + ' - ' + score_card['final_score_min'].astype(str)
        return score_card

    # transform all variables into WOE values
    def woe_transform(self, df, IV, threshold):
        transform_prefix = 'WOE_'
        for x in IV:
            if IV[x]["iv"] > threshold and x in df.columns:
                df[transform_prefix + x]=IV[x]["woe"].transform(df[x], metric="woe")