import logging
import time
import pandas as pd
import numpy as np

from abc import ABC
from typing import Any
from skopt import BayesSearchCV

from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, train_test_split
from mlapp.feature_engineering import FeatureEngineering
from mlapp.matrix import Metrics

Pipeline = FeatureEngineering.Pipeline

class BaseModel(ABC):
    """
    Abstract base class for machine learning models with preprocessing, 
    training, hyperparameter tuning, prediction, and evaluation support.

    Provides:
        - Train-test split with optional stratification
        - Preprocessing via a FeatureEngineering pipeline
        - Hyperparameter tuning (grid, random, Bayesian)
        - Prediction and probability estimation
        - Input feature schema extraction
        - Classification metrics computation
        - Progress logging and execution tracking
    """
    def __init__(self, model: Any, model_name: str):
        self.model = model
        self.model_name = model_name
        self.input_feature={}
        self.tuning_params=None
        self.info={}
        self.art=None
        self.best_params_=None
        self.data_pipeline: Pipeline = Pipeline()
        self.start_time = None
        self.end_time = None
        self.status = "initialized"
        self.current_stage = None
        self.progress = {} 
        self.metrics={}
        self.origin_feature_info = []

        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s | %(levelname)s | %(message)s"
        )
        self.logger = logging.getLogger(model_name)
        
        self.get_info()
    
    def get_info(self):
        """Return back the Model information from `build_info`."""
        self.build_info()
        return self.info
    
    def build_info(self):
        """
        Build and store basic information about the model.

        Constructs a dictionary `self.info` containing key model details, including:
            - model name and type
            - whether the model is fitted and number of features
            - model parameters and best parameters
            - evaluation metrics
            - training status
            - execution time (if start and end times are recorded)
        """
        self.info = {
            "model_name": self.model_name,
            "model_type": type(self.model).__name__,
            "is_fitted": hasattr(self.model, "n_features_in_"),
            "n_features": getattr(self.model, "n_features_in_", None),
            "params": self.model.get_params() if hasattr(self.model, "get_params") else None,
            "best_params": self.best_params_,
            "metrics": self.metrics,
            "status": self.status,
            "execution time": (
                self.end_time - self.start_time
                if self.start_time and self.end_time
                else None
            )
        }
        return self
    
    def get_input_feature(self):
        """
        Return back the schema of input features from `build_input_feature`.
        """
        if not hasattr(self, "input_feature") or not self.input_feature:
            self.build_input_feature()
        return self.input_feature

    def build_input_feature(self):
        """
        Construct a schema of input features expected by the model.

        Builds a list of dictionaries describing each feature with:
            - "***name***": feature name
            - "***type***": data type from original metadata (or "unknown")
            - "***required***": whether the feature is required

        Features are inferred from the trained model, preprocessing artifact, or
        original feature info. Duplicates are removed while preserving order.
        """
        # Get model features
        if hasattr(self.model, "feature_names_in_"):
            trained_features = list(self.model.feature_names_in_)
        elif hasattr(self.art, "multicollinearity") and self.art.multicollinearity is not None and hasattr(self.art.multicollinearity, "selected_cols"):
            trained_features = list(self.art.multicollinearity.selected_cols)
        else:
            # in case, feature selection excluded
            trained_features = [f['name'] for f in self.origin_feature_info]

        # Remove duplicates while preserving order
        seen = set()
        trained_features = [f for f in trained_features if not (f in seen or seen.add(f))]

        # Create a dict for easy lookup
        origin_info_map = {f['name']: f['type'] for f in self.origin_feature_info}

        # Build input_feature
        self.input_feature = [
            {
                "name": f,
                "type": origin_info_map.get(f, "unknown"),
                "required": True
            }
            for f in trained_features
        ]
        
    def _update_progress(self, stage, message=None, **kwargs):
        """
        Update the current training stage and log progress.

        Parameters
        ----------
        stage : str
            Name of the current stage (e.g., 'train', 'preprocess').
        message : str, optional
            Optional message to include in the log.
        **kwargs : dict
            Additional progress information to store in `self.progress`.
        """
        self.current_stage = stage
        self.progress.update(kwargs)

        log_msg = f"[{stage.upper()}]"
        if message:
            log_msg += f" {message}"

        self.logger.info(log_msg)

    def fit(self, X, y, search_method=None, tuning_params=None, test_size=0.2, cv=5,
            scoring='accuracy', n_iter=10, random_state=42, stratify=False):
        """
        Fit the model on the provided data, optionally performing preprocessing 
        and hyperparameter tuning, and return the train/test splits.

        This method performs the following steps:
        1. Train-test split (with optional stratification).
        2. Fit and transform data using a preprocessing pipeline (if defined).
        3. Train the model using the specified hyperparameter search method.
        4. Log training progress and timing information.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix for training.
        y : pd.Series
            Target vector corresponding to X.
        search_method : str, optional (default=None)
            Hyperparameter search strategy. Options are:
            - ***None***: train on full data without tuning.
            - '***grid***': GridSearchCV.
            - '***random***': RandomizedSearchCV.
            - '***bayes***': Bayesian optimization via BayesSearchCV.
        tuning_params : dict, optional (default=None)
            Dictionary of hyperparameters to tune. Ignored if `search_method` is None.
        test_size : float, optional (default=0.2)
            Proportion of the dataset to allocate for validation/testing.
        cv : int, optional (default=5)
            Number of folds for cross-validation during hyperparameter search.
        scoring : str, optional (default='accuracy')
            Metric used to evaluate model performance during search/training.
        n_iter : int, optional (default=10)
            Number of iterations for randomized or Bayesian search.
        random_state : int, optional (default=42)
            Seed for reproducibility.
        stratify : bool, optional (default=False)
            Whether to stratify the train/test split according to the target `y`.

        Returns
        -------
        X_test : pd.DataFrame
            Test features after optional preprocessing.
        y_test : pd.Series
            Test target values.
        """
        try:
            self.status = "Training started"
            self.start_time = time.time()
            self.origin_feature_info = [
                {
                    "name": col,
                    "type": str(dtype),  # just use the original pandas dtype
                    "required": True
                }
                for col, dtype in X.dtypes.items()
            ]

            # ----------------------------
            # 1. Split
            # ----------------------------
            self._update_progress("split", "Train-test split started")

            X_train, X_test, y_train, y_test = train_test_split(
                X, y, 
                test_size=test_size, 
                random_state=random_state,
                stratify=y if stratify else None
            )

            # ----------------------------
            # 2. Preprocessing
            # ----------------------------
            if len(self.data_pipeline._steps) > 0:
                self._update_progress("preprocess", "Fitting data pipeline")
                self.art = FeatureEngineering.fit_pipeline(X_train, y_train, self.data_pipeline)

                X_train = FeatureEngineering.transform_pipeline(X_train, self.art, y=y_train, is_train=True)
                # X_test = FeatureEngineering.transform_pipeline(X_test, self.art, y=y_train, is_train=False)
            else:
                self._update_progress("data_preprocess", "NO data pipeline")

            # ----------------------------
            # 3. Training / Search
            # ----------------------------
            self._update_progress("train", f"Training started ({search_method})")

            param_grid = tuning_params if tuning_params is not None else self.tuning_params

            if search_method is None:
                self.model.fit(X_train, y_train)
                self.best_params_ = self.model.get_params()

            elif search_method.lower() == "grid":
                self._update_progress("search", "GridSearch running", total_candidates=len(param_grid))
                search = GridSearchCV(
                    self.model, param_grid, cv=cv,
                    scoring=scoring, n_jobs=-1, verbose=1 
                )
                search.fit(X_train, y_train)
                self.model = search.best_estimator_
                self.best_params_ = search.best_params_
                self.progress["best_score"] = search.best_score_

            elif search_method.lower() == "random":
                self._update_progress("search", "RandomSearch running", n_iter=n_iter)
                search = RandomizedSearchCV(
                    self.model, param_grid, n_iter=n_iter,
                    cv=cv, scoring=scoring, n_jobs=-1, random_state=random_state
                )
                search.fit(X_train, y_train)
                self.model = search.best_estimator_
                self.best_params_ = search.best_params_
                self.progress["best_score"] = search.best_score_

            elif search_method.lower() == "bayes":
                self._update_progress("search", "Bayesian Optimization running", n_iter=n_iter)
                search = BayesSearchCV(
                    self.model, param_grid, n_iter=n_iter,
                    cv=cv, scoring=scoring, n_jobs=-1, random_state=random_state
                )
                search.fit(X_train, y_train)
                self.model = search.best_estimator_
                self.best_params_ = search.best_params_
                self.progress["best_score"] = search.best_score_

            self.status = "Training completed"

        except Exception as e:
            self.status = "Training failed"
            self.logger.error(f"Training failed: {str(e)}")
            raise

        finally:
            self.end_time = time.time()
            self.input_feature = self.get_input_feature()

        self.logger.info(f"Training finished in {self.end_time - self.start_time:.2f}s")
        return X_test, y_test
    
    def validate_data(self, data):
        """
        Validate and standardize input data into a pandas DataFrame. 
        Accepts input data in multiple formats and converts it to a DataFrame suitable for model processing.

        Parameters
        ----------
        data : dict, list of dicts, or pd.DataFrame
            Input data to validate:
            - dict : a single record; will be converted to a DataFrame with one row.
            - list : list of dicts; each dict represents a row.
            - pd.DataFrame : a DataFrame; will be copied to avoid modifying the original.

        Returns
        -------
        df : pd.DataFrame
            A pandas DataFrame containing the validated input data.
        """
        if isinstance(data, dict):
            df = pd.DataFrame([data])
        elif isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, pd.DataFrame):
            df = data.copy()
        else:
            raise ValueError(f"Unsupported input type: {type(data)}")
        
        return df
        
    def predict(self, X):
        """Generate predictions for the input data, applying preprocessing if available.

        Parameters
        ----------
        X : dict, list of dicts, or pd.DataFrame
            Input data to predict. Supported formats:
            - dict : a single record (converted to a one-row DataFrame)
            - list of dicts : multiple records
            - pd.DataFrame : directly used (copied internally)

        Returns
        -------
        y_pred : np.ndarray or pd.Series
            Predictions generated by the trained model.
        X_final : pd.DataFrame
            Input features after applying the preprocessing pipeline (`self.art`) if available."""
        df = self.validate_data(X)
        if self.art:
            X_final = FeatureEngineering.transform_pipeline(df, self.art, is_train=False)
        else:
            X_final = df
        if hasattr(self.model, "predict"):
            y_pred = self.model.predict(X_final)
        return y_pred

    def predict_proba(self, X):
        """Generate predictions for the input data, applying preprocessing if available.

        Parameters
        ----------
        X : dict, list of dicts, or pd.DataFrame
            Input data to predict. Supported formats:
            - dict : a single record (converted to a one-row DataFrame)
            - list of dicts : multiple records
            - pd.DataFrame : directly used (copied internally)

        Returns
        -------
        proba_dicts : list[dict]
            Each dict maps class label -> probability for one row."""
        df = self.validate_data(X)
        if self.art:
            X_final = FeatureEngineering.transform_pipeline(df, self.art, is_train=False)
        else:
            X_final = df
        if hasattr(self.model, "predict_proba"):
            y_pred_proba = self.model.predict_proba(X_final)
            classes = self.model.classes_
            
        proba_dicts = [
            {str(cls): float(prob) for cls, prob in zip(classes, row)}
            for row in y_pred_proba
        ]
        return proba_dicts
    
    @staticmethod
    def _proba_dicts_to_array(y_proba_dicts, classes):
        """
        Convert:
        [{0: 0.9, 1: 0.1}, ...]
        → np.ndarray (n, n_classes)
        """
        return np.array([
            [row[str(cls)] for cls in classes]
            for row in y_proba_dicts
        ])
    
    def build_metrics(self, y_test, y_pred, y_pred_proba=None, keys=None):
        """
        Build and return classification performance metrics for model predictions.

        Parameters
        ----------
        y_test : array-like
            Ground-truth class labels.
        y_pred : array-like
            Predicted class labels.
        y_pred_proba : array-like, pandas.DataFrame, or list of dicts, optional
            Predicted class probabilities. Supported formats include:
            - 2-D NumPy array of shape (n_samples, n_classes)
            - pandas DataFrame with one column per class
            - list of dictionaries mapping class label → probability
            (as returned by `predict_proba`)
        keys : list of str or None, optional
            If provided, only the specified metric keys are returned from the full
            classification report. If None, all available metrics are returned.

        Returns
        -------
        dict
            A dictionary containing either the full classification report or the
            selected subset of metrics specified by `keys`. The report may include
            standard classification metrics as well as additional analytics such as
            lift and gain curves when probabilities are supplied.
        """
        # Convert y_pred to numpy
        y_pred = np.asarray(y_pred)

        # Convert proba dicts → array if needed
        if y_pred_proba is not None:
            if isinstance(y_pred_proba, list) and isinstance(y_pred_proba[0], dict):
                y_pred_proba = self._proba_dicts_to_array(
                    y_pred_proba,
                    classes=self.model.classes_
                )
            else:
                y_pred_proba = np.asarray(y_pred_proba)

        report = Metrics.classification_report(
            y_true=y_test,
            y_pred=y_pred,
            y_proba=y_pred_proba,
            compute_lift_gain=True,
            compute_psi_score=False
        )

        if keys is None:
            self.metrics = report
            return self.metrics

        # Otherwise select requested metrics only
        self.metrics = Metrics.select_from_classification_report(rep=report, keys=keys)
        self.build_info()

        return self.metrics
