# Initialize model
import sys
sys.path.append("backend/mlapp_repo")
import pandas as pd

from typing import Mapping, Literal, Callable, Any
from numpy.random import RandomState
from mlapp.ml.classification.base import BaseModel
from sklearn.svm import SVC


class SVCModel(BaseModel):
    """
    Configurable Support Vector Machine (SVM) classifier based on sklearn.svm.SVC.

    Parameters
    ----------
    C : float, default=1.0
        Regularization parameter.
    kernel : {'linear', 'poly', 'rbf', 'sigmoid', 'precomputed'} or callable, default='rbf'
        Kernel type to use.
    degree : int, default=3
        Degree for 'poly' kernel. Ignored by other kernels.
    gamma : {'scale', 'auto'} or float, default='scale'
        Kernel coefficient for 'rbf', 'poly', and 'sigmoid'.
    coef0 : float, default=0.0
        Independent term for 'poly' and 'sigmoid' kernels.
    shrinking : bool, default=True
        Whether to use the shrinking heuristic.
    probability : bool, default=False
        Whether to enable probability estimates.
    tol : float, default=1e-3
        Tolerance for stopping criterion.
    cache_size : float, default=200
        Size of kernel cache (MB).
    class_weight : dict, 'balanced', or None, default=None
        Weights associated with classes.
    verbose : bool, default=False
        Enable verbose output.
    max_iter : int, default=-1
        Maximum iterations for solver.
    decision_function_shape : {'ovo', 'ovr'}, default='ovr'
        Multi-class strategy.
    break_ties : bool, default=False
        Whether to break ties in decision function.
    random_state : int, RandomState, or None, default=None
        Random state for probability estimates and shuffling.
    """
    def __init__(
        self,
        *,
        C: float = 1.0,
        kernel: Callable[..., Any] | Literal["linear", "poly", "rbf", "sigmoid", "precomputed"] = "rbf",
        degree: int = 3,
        gamma: float | Literal["scale", "auto"] = "scale",
        coef0: float = 0.0,
        shrinking: bool = True,
        probability: bool = True,
        tol: float = 1e-3,
        cache_size: float = 200,
        class_weight: Mapping | str | None = None,
        verbose: bool = False,
        max_iter: int = -1,
        decision_function_shape: Literal["ovo", "ovr"] = "ovr",
        break_ties: bool = False,
        random_state: int | RandomState | None = None,
    ):
        model = SVC(
            C=C,
            kernel=kernel,
            degree=degree,
            gamma=gamma,
            coef0=coef0,
            shrinking=shrinking,
            probability=probability,
            tol=tol,
            cache_size=cache_size,
            class_weight=class_weight,
            verbose=verbose,
            max_iter=max_iter,
            decision_function_shape=decision_function_shape,
            break_ties=break_ties,
            random_state=random_state,
        )
        model_name = "Wing SVM"
        super().__init__(model=model, model_name=model_name)
        
        # default params for hyperparams tuning process
        self.tuning_params={
            "C": [0.1, 1, 10, 100],
            "kernel": ["linear", "rbf", "poly"],
            "gamma": ["scale", "auto"],
            "degree": [2, 3, 4]  # used only for poly
        }

    def set_tuning_params(
        self, 
        C: list[float] | None = None, 
        kernel: list[str] | None = None, 
        gamma: list[str] | None = None, 
        degree: list[int] | None = None
    ) -> None:
        """
        Update the hyperparameter grid for model tuning for SVM.

        Parameters
        ----------
        C : list of float, optional
            Regularization parameter values (default: [0.1, 1, 10, 100]).
        kernel : list of str, optional
            Kernel types to try. Options include 'linear', 'rbf', 'poly' (default: ['linear', 'rbf', 'poly']).
        gamma : list of str, optional
            Kernel coefficient options: 'scale' or 'auto' (default: ['scale', 'auto']).
        degree : list of int, optional
            Degree of the polynomial kernel (only used if kernel='poly', default: [2, 3, 4]).
        """
        if C is not None:
            self.tuning_params["C"] = C
        if kernel is not None:
            self.tuning_params["kernel"] = kernel
        if gamma is not None:
            self.tuning_params["gamma"] = gamma
        if degree is not None:
            self.tuning_params["degree"] = degree
