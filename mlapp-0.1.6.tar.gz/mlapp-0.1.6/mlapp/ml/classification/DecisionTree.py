from sklearn.tree import DecisionTreeClassifier
from mlapp.ml.classification.base import BaseModel
import pandas as pd
from pathlib import Path
from mlapp import mmt


class DecisionTree(BaseModel):

    def __init__(self):
        model = DecisionTreeClassifier()

        super().__init__(
            model=model, model_name="Decision Tree Classifier"
        )
        
        self.tuning_params = {
                "criterion": ["gini", "entropy", "log_loss"],
                "max_depth": [None, 3, 5, 10, 20],
                "min_samples_split": [2, 5, 10],
                "min_samples_leaf": [1, 2, 5],
                "max_features": [None, "sqrt", "log2"]
            }
        
    def set_tuning_params(
        self,
        criterion: list[str] | None = None,
        max_depth: list[int | None] | None = None,
        min_samples_split: list[int] | None = None,
        min_samples_leaf: list[int] | None = None,
        max_features: list[str | None] | None = None
    ) -> None:
        """
        Update the hyperparameter grid for model tuning for Decision Tree.

        Parameters
        ----------
        criterion : list of str, optional
            Function to measure the quality of a split
            (default: ['gini', 'entropy', 'log_loss']).

        max_depth : list of int or None, optional
            Maximum depth of the tree
            (default: [None, 3, 5, 10, 20]).

        min_samples_split : list of int, optional
            Minimum number of samples required to split an internal node
            (default: [2, 5, 10]).

        min_samples_leaf : list of int, optional
            Minimum number of samples required to be at a leaf node
            (default: [1, 2, 5]).

        max_features : list of str or None, optional
            Number of features to consider when looking for the best split
            (default: [None, 'sqrt', 'log2']).
        """
        if criterion is not None:
            self.tuning_params["criterion"] = criterion
        if max_depth is not None:
            self.tuning_params["max_depth"] = max_depth
        if min_samples_split is not None:
            self.tuning_params["min_samples_split"] = min_samples_split
        if min_samples_leaf is not None:
            self.tuning_params["min_samples_leaf"] = min_samples_leaf
        if max_features is not None:
            self.tuning_params["max_features"] = max_features


if __name__ == '__main__':
    BASE_DIR = Path(__file__).resolve().parent
    csv_path = BASE_DIR.parent / "data" / "synthetic_bank_churn.csv"
    df = pd.read_csv(csv_path)

    X = df.drop(columns=["churn_flag"])
    y = df["churn_flag"]
    model = DecisionTree()
    model.set_tuning_params()

    model.data_pipeline.schema(enforce=True) \
            .infer_columns() \
            .impute(add_missing_indicators=True) \
            .rare_categories(min_freq=2) \
            .outliers(method="quantile", low_q=0.01, high_q=0.99) \
            .multicollinearity_corr(threshold=0.8) \
            .build()

    # model.feature_pipeline.multicollinearity_corr(threshold=0.8)

    # Train
    X_test, y_test = model.fit(
        X, y, search_method='random', tuning_params=model.tuning_params
    )

    # Predict
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)
    # print(y_pred)
    print(y_pred_proba)

    # metrics
    model.build_metrics(y_test, y_pred, y_pred_proba,keys=[
            "accuracy"
        ])
    print("Matrics: ", model.metrics)
    # print(model.info)
    # print("Input Feature: ", model.input_feature)


    # with mmt(experiment_name="churn_prediction_1", server_url="http://127.0.0.1:8000/ade/api/mlapp_v2") as app:
    #     # Attach your trained model
    #     app.attach_model(model)
        
    #     # Log the model into the experiment
    #     app.log_model()
        
    # data = {
    #     "age": 56,
    #     "tenure_months": 9,
    #     "balance": 163118.99,
    #     "num_products": 2,
    #     "credit_score": 772,
    #     "is_active_member": 1,
    #     "has_credit_card": 1,
    #     "monthly_income": 10838.53
    # }

    

    # with mmt(experiment_name="churn_prediction", server_url="http://127.0.0.1:8000/ade/api/mlapp_v2") as app:
    #     model = app.load_model(model_name="churn_prediction_1", version=1)

    # pred = model.predict(data)
    # y_pred_proba = model.predict_predict_proba(data)
    # print(pred)
    
    
    # to run under dir mlapp_repo:
    #     python -m mlapp.ml.classification.DecisionTree