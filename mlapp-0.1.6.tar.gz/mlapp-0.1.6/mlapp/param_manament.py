import os
import json
import getpass
import requests
from datetime import datetime, timezone

class ParamStore:
    def __init__(self, server_url: str):
        self.server_url = server_url

    # ----------------------------
    # Experiments & Runs
    # ----------------------------
    def create_experiment(self, experiment_name: str):
        url = f"{self.server_url}/experiments/create"
        res = requests.post(url, json={"experiment_name": experiment_name})
        res.raise_for_status()
        return res.json()

    def create_run(self, experiment_name: str, run_uuid: str, start_time=None):
        url = f"{self.server_url}/runs/create"
        username = getpass.getuser()
        payload = {
            "experiment_name": experiment_name,
            "run_uuid": run_uuid,
            "start_time": start_time or datetime.now(timezone.utc).isoformat(),
            "user_id": username,
        }
        res = requests.post(url, json=payload)
        res.raise_for_status()
        return res.json()

    def finish_run(self, run_id: str, status="FINISHED"):
        url = f"{self.server_url}/runs/finish"
        payload = {
            "run_id": run_id,
            "status": status,
            "end_time": datetime.now(timezone.utc).isoformat()
        }
        res = requests.post(url, json=payload)
        res.raise_for_status()
        return res.json()

    # ----------------------------
    # Params & Metrics
    # ----------------------------
    def log_param(self, run_id: str, key: str, value):
        url = f"{self.server_url}/params/log"
        
        payload = {
            "run_id": run_id, 
            "params": {key: value}
            }
        
        res = requests.post(url, json=payload)
        res.raise_for_status()

    def log_metric(self, run_id: str, key: str, value, step: int = 0, timestamp: int | None = None,):
        url = f"{self.server_url}/metrics/log"

        if timestamp is None:
            timestamp = int(datetime.now(timezone.utc).timestamp() * 1000)

        payload = {
            "run_id": run_id,
            "metrics": {
                key: {
                    "value": float(value),
                    "step": step,
                    "timestamp": timestamp
                }
            }
        }

        res = requests.post(url, json=payload)
        res.raise_for_status()

    # ----------------------------
    # Artifacts & Models
    # ----------------------------
    def log_artifact(self, run_id: str, local_path: str, artifact_name: str, experiment_name: str = None):
        url = f"{self.server_url}/artifacts/upload"
        with open(local_path, "rb") as f:
            files = {"file": (os.path.basename(local_path), f)}
            data = {"run_id": run_id, "experiment_name": experiment_name, "artifact_name": artifact_name or os.path.basename(local_path)}
            res = requests.post(url, files=files, data={"metadata": json.dumps(data)})
        res.raise_for_status()
        return res.json()


    def create_or_get_model(self, experiment_name: str, model_name: str, metadata: dict | None = None):
        url = f"{self.server_url}/models/create_or_get"
        payload = {"experiment_name": experiment_name, "model_name": model_name, "metadata": metadata or {}}
        res = requests.post(url, json=payload)
        res.raise_for_status()
        return res.json()

    def create_model_version(self, model_id: str, run_id: str, source: str, description: str = None, metadata: dict | None = None):
        url = f"{self.server_url}/models/versions/create"
        payload = {
            "model_id": model_id,
            "run_id": run_id,
            "source": source,
            "description": description,
            "metadata": metadata or {}
        }
        res = requests.post(url, json=payload)
        res.raise_for_status()
        return res.json()

    def get_model_version(self, model_name: str, version: int | None = None):
        url = f"{self.server_url}/models/versions/get"
        payload = {"model_name": model_name, "version": version}
        res = requests.get(url, params=payload)
        return res.json()

    def load_model_from_uri(self, artifact_uri: str, save_to: str | None = None):
        url = f"{self.server_url}/artifacts/download"
        res = requests.get(url, params={"artifact_uri": artifact_uri}, stream=True)
        res.raise_for_status()

        import cloudpickle
        import tempfile

        if save_to:
            with open(save_to, "wb") as f:
                for chunk in res.iter_content(chunk_size=8192):
                    f.write(chunk)
            with open(save_to, "rb") as f:
                return cloudpickle.load(f)

        tmp = tempfile.NamedTemporaryFile(delete=False)
        for chunk in res.iter_content(chunk_size=8192):
            tmp.write(chunk)
        tmp.close()

        with open(tmp.name, "rb") as f:
            model = cloudpickle.load(f)

        os.remove(tmp.name)
        return model
