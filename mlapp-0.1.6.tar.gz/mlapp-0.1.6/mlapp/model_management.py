import os
import json
import secrets
import tempfile
import cloudpickle
from datetime import datetime, timezone

from .param_manament import ParamStore

def generate_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(8)}"


class Mlapp:
    def __init__(self, experiment_name: str, server_url: str):
        self.experiment_name = experiment_name
        self.server_url = server_url
        self.store = ParamStore(server_url)

        self.model = None
        self.run_uuid = None

        self._model_metadata: dict = {}


    def __enter__(self):
        self.run_uuid = generate_id("run")
        self.start_time = datetime.now(timezone.utc)

        self.store.create_experiment(self.experiment_name)
        self.store.create_run(self.experiment_name, self.run_uuid, start_time=self.start_time.isoformat())
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "FAILED" if exc_type else "FINISHED"
        self.end(status=status)
        return False


    def attach_model(self, model):
        self.model = model


    def log_param(self, key: str, value):
        if not self.run_uuid:
            raise RuntimeError("Run not started")

        self.store.log_param(
            run_id=self.run_uuid,
            key=str(key),
            value=str(value),
        )

    def log_params(self, params: dict):
        if not isinstance(params, dict):
            raise TypeError("params must be a dict")

        for k, v in params.items():
            self.log_param(k, v)

    def log_metric(
        self,
        key: str,
        value: float,
        step: int = 0,
        timestamp: int | None = None,
    ):
        if not self.run_uuid:
            raise RuntimeError("Run not started")

        if timestamp is None:
            timestamp = int(datetime.now(timezone.utc).timestamp() * 1000)

        self.store.log_metric(
            run_id=self.run_uuid,
            key=str(key),
            value=float(value),
            step=int(step),
            timestamp=timestamp,
        )

    def log_metrics(self, metrics: dict, step: int = 0):
        if not isinstance(metrics, dict):
            raise TypeError("metrics must be a dict")

        for k, v in metrics.items():
            self.log_metric(k, v, step=step)


    def log_metadata(self, key: str, value):
        """Generic metadata setter"""
        self._model_metadata[key] = value


    def set_model_info(
        self,
        model_type: str,
        framework: str,
        algorithm: str | None = None,
        version: str | None = None,
    ):
        self._model_metadata.update({
            "model_type": model_type,
            "framework": framework,
            "algorithm": algorithm,
            "version": version,
        })

    def set_schema(self, input_schema: dict, output_schema: dict):
        self._model_metadata["input_schema"] = input_schema
        self._model_metadata["output_schema"] = output_schema

    def set_metrics(self, metrics: dict):
        self._model_metadata["metrics"] = metrics

    def set_training_data_info(self, info: dict):
        self._model_metadata["training_data"] = info

    def set_inference_config(self, config: dict):
        self._model_metadata["inference"] = config

    def set_runtime_requirements(self, requirements: dict):
        self._model_metadata["runtime_requirements"] = requirements


    def log_model(
        self,
        artifact_name: str = "model.pkl",
        description: str | None = None,
        upload_remote: bool = True,
    ):
        if self.model is None:
            raise ValueError("No model attached")

        model_tmp_path = self._serialize_model()
        metadata_tmp_path = None

        try:
            # 1️⃣ Upload model.pkl
            model_artifact = self.store.log_artifact(
                run_id=self.run_uuid,
                local_path=model_tmp_path,
                experiment_name=self.experiment_name,
                artifact_name=artifact_name,
            )

            # 2️⃣ Register / get model
            model_info = self.store.create_or_get_model(
                model_name=self.experiment_name,
                experiment_name=self.experiment_name,
                metadata=self._model_metadata,
            )
            model_id = model_info["model_id"]

            # 3️⃣ Create model version
            version_info = self.store.create_model_version(
                model_id=model_id,
                run_id=self.run_uuid,
                source=model_artifact["artifact_uri"],
                description=description,
                metadata=self._model_metadata,
            )
            version = version_info["version"]
            print(f"Model {self.experiment_name} saved successful, with version {version}")

            # 4️⃣ Build metadata.json (canonical contract)
            metadata_payload = {
                "model_name": self.experiment_name,
                "model_id": model_id,
                "experiment_name": self.experiment_name,
                "run_id": self.run_uuid,

                "version": self._model_metadata.get("version", str(version)),
                "model_type": self._model_metadata.get("model_type"),
                "framework": self._model_metadata.get("framework"),
                "algorithm": self._model_metadata.get(
                    "algorithm", type(self.model).__name__
                ),

                "created_at": datetime.now().isoformat() + "Z",
                "trained_by": "mlapp",
                "artifact_format": "cloudpickle",
                "artifact_uri": model_artifact["artifact_uri"],

                "signature_version": "v1",
            }

            # merge staged metadata
            metadata_payload.update(self._model_metadata)

            # remove nulls
            metadata_payload = {
                k: v for k, v in metadata_payload.items() if v is not None
            }

            # 5️⃣ Write metadata.json
            metadata_tmp_path = f"{model_tmp_path}.metadata.json"
            with open(metadata_tmp_path, "w", encoding="utf-8") as f:
                json.dump(metadata_payload, f, indent=2)

            # 6️⃣ Upload metadata.json
            self.store.log_artifact(
                run_id=self.run_uuid,
                local_path=metadata_tmp_path,
                experiment_name=self.experiment_name,
                artifact_name="metadata.json",
            )

            return model_id, version

        finally:
            if os.path.exists(model_tmp_path):
                os.remove(model_tmp_path)
            if metadata_tmp_path and os.path.exists(metadata_tmp_path):
                os.remove(metadata_tmp_path)


    def load_model(self, model_name: str, version: int | None = None):
        info = self.store.get_model_version(model_name, version)
        artifact_uri = info["storage_location"]
        return self.store.load_model_from_uri(artifact_uri)


    def end(self, status: str = "FINISHED"):
        if self.run_uuid:
            self.store.finish_run(self.run_uuid, status=status)


    def _serialize_model(self) -> str:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pkl") as tmp:
            cloudpickle.dump(self.model, tmp)
            return tmp.name
